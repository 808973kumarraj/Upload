import { SimulationTopic } from '../types/simulation';
import { SPARK_CATALYST_TOPIC } from './sparkCatalyst/definition';
import { VOLCANO_OPTIMIZER_TOPIC } from './volcanoOptimizer/definition';

export const SIMULATION_TOPICS: SimulationTopic[] = [
  SPARK_CATALYST_TOPIC,
  VOLCANO_OPTIMIZER_TOPIC,
];

export function getTopicById(id: string): SimulationTopic {
  const found = SIMULATION_TOPICS.find((t) => t.id === id);
  return found || SPARK_CATALYST_TOPIC;
}

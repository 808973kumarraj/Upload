/**
 * WholeStageCodegen code generator.
 * Synthesizes the Janino Java bytecode representation corresponding to the physical plan.
 */

export interface CodegenConfig {
  joinType: string;
  hasFilter: boolean;
  filterPushedToScan: boolean;
  columnsPruned: boolean;
  wholeStageEnabled: boolean;
  tableName1: string;
  tableName2?: string;
}

export function generateJaninoJavaCode(config: CodegenConfig): string {
  if (!config.wholeStageEnabled) {
    return `// Whole-Stage Code Generation is DISABLED (spark.sql.codegen.wholeStage = false)
// Spark falls back to Volcano Iterator Model with virtual method invocation:
//
// while (child.hasNext()) {
//     InternalRow row = child.next();
//     if (filter.eval(row)) {
//         return project.eval(row);
//     }
// }
// ⚠️ High CPU cache misses and heavy virtual function call dispatch per row.`;
  }

  const isBroadcast = config.joinType === 'BroadcastHashJoin';

  return `/* 
 * Apache Spark Whole-Stage Java Code Generation (Janino Compiler)
 * Stage 1 / GeneratedIteratorForCodegenStage1
 * Project Tungsten: Zero virtual dispatch, unrolled CPU pipelining
 */
package org.apache.spark.sql.catalyst.expressions;

import org.apache.spark.sql.execution.BufferedRowIterator;
import org.apache.spark.sql.catalyst.InternalRow;
import org.apache.spark.sql.catalyst.expressions.codegen.UnsafeRowWriter;
import org.apache.spark.sql.execution.joins.LongHashedRelation;

public final class GeneratedIteratorForCodegenStage1 extends BufferedRowIterator {
    private scala.collection.Iterator<InternalRow> inputScan;
    ${isBroadcast ? 'private LongHashedRelation broadcastRelation;' : ''}
    private UnsafeRowWriter rowWriter;

    public GeneratedIteratorForCodegenStage1(Object[] references) {
        this.inputScan = (scala.collection.Iterator<InternalRow>) references[0];
        ${isBroadcast ? 'this.broadcastRelation = (LongHashedRelation) references[1];' : ''}
        this.rowWriter = new UnsafeRowWriter(6, 64);
    }

    @Override
    protected void processNext() throws java.io.IOException {
        // Direct unrolled while loop over partition batches (no virtual next() calls)
        while (inputScan.hasNext()) {
            InternalRow scanRow = (InternalRow) inputScan.next();

            ${!config.filterPushedToScan && config.hasFilter ? `// In-Memory Filter evaluation
            long amount = scanRow.getLong(3);
            if (!(amount > 25000L)) {
                continue; // Predicate rejected
            }` : '// [Filter Pushdown Active]: Predicate evaluated in Parquet Vectorized Reader'}

            ${isBroadcast ? `// Fast Broadcast Hash Table Probe (O(1) memory lookup)
            long joinKey = scanRow.getLong(1);
            InternalRow matchedBuildRow = broadcastRelation.getValue(joinKey);
            if (matchedBuildRow == null) {
                continue; // Inner join condition failed
            }` : `// Stream side record passed to downstream SortMergeJoin buffer`}

            // Materialize Tungsten UnsafeRow into off-heap memory buffer
            rowWriter.reset();
            rowWriter.write(0, scanRow.getLong(0));   // order_id
            rowWriter.write(1, scanRow.getLong(1));   // customer_id
            ${isBroadcast ? 'rowWriter.write(2, matchedBuildRow.getUTF8String(1)); // customer_name' : ''}
            
            append(rowWriter.getRow());
            if (shouldStop()) return;
        }
    }
}`;
}

import { ValidationResult } from '../../types/simulation';

export interface ParsedQuery {
  raw: string;
  selectColumns: Array<{ name: string; alias?: string; line: number }>;
  fromTable: { name: string; alias?: string; line: number };
  joins: Array<{
    type: 'INNER' | 'LEFT' | 'RIGHT' | 'FULL';
    table: string;
    alias?: string;
    condition: string;
    line: number;
  }>;
  whereClauses: Array<{ expression: string; line: number }>;
  groupByColumns: Array<{ name: string; line: number }>;
  havingClauses: Array<{ expression: string; line: number }>;
  orderByColumns: Array<{ name: string; direction: 'ASC' | 'DESC'; line: number }>;
  lineMap: {
    selectLine: number;
    fromLine: number;
    whereLine: number;
    joinLines: number[];
    groupByLine?: number;
    orderByLine?: number;
  };
}

export function parseSparkQuery(queryText: string): { parsed?: ParsedQuery; error?: string } {
  const lines = queryText.split('\n');
  const cleanLines = lines.map((l) => l.trim());

  if (!queryText.trim()) {
    return { error: 'Empty query. Please provide a valid Spark SQL query or DataFrame operation.' };
  }

  // Find key clauses
  let selectStart = -1;
  let fromStart = -1;
  let whereStart = -1;
  let groupByStart = -1;
  let havingStart = -1;
  let orderByStart = -1;

  for (let i = 0; i < cleanLines.length; i++) {
    const line = cleanLines[i].toUpperCase();
    if (line.startsWith('SELECT')) selectStart = i + 1;
    else if (line.startsWith('FROM')) fromStart = i + 1;
    else if (line.startsWith('WHERE')) whereStart = i + 1;
    else if (line.startsWith('GROUP BY')) groupByStart = i + 1;
    else if (line.startsWith('HAVING')) havingStart = i + 1;
    else if (line.startsWith('ORDER BY')) orderByStart = i + 1;
  }

  if (selectStart === -1) {
    return { error: 'Syntax Error: Missing SELECT statement in query.' };
  }
  if (fromStart === -1) {
    return { error: 'Syntax Error: Missing FROM clause in query.' };
  }

  // Extract from table
  const fromLineIdx = fromStart - 1;
  const fromLineText = lines[fromLineIdx].replace(/--.*$/, '').trim();
  const fromMatch = fromLineText.match(/FROM\s+([a-zA-Z0-9_]+)(?:\s+([a-zA-Z0-9_]+))?/i);
  if (!fromMatch) {
    return { error: `Invalid FROM clause at line ${fromStart}: Expected table identifier.` };
  }

  const fromTable = {
    name: fromMatch[1].toLowerCase(),
    alias: fromMatch[2] ? fromMatch[2].toLowerCase() : fromMatch[1].toLowerCase(),
    line: fromStart,
  };

  // Extract joins
  const joins: ParsedQuery['joins'] = [];
  const joinLines: number[] = [];
  for (let i = 0; i < lines.length; i++) {
    const rawLine = lines[i].replace(/--.*$/, '').trim();
    const joinMatch = rawLine.match(/(?:(INNER|LEFT|RIGHT|FULL)\s+)?JOIN\s+([a-zA-Z0-9_]+)(?:\s+([a-zA-Z0-9_]+))?\s+ON\s+(.*)/i);
    if (joinMatch) {
      const type = (joinMatch[1]?.toUpperCase() || 'INNER') as any;
      joins.push({
        type,
        table: joinMatch[2].toLowerCase(),
        alias: joinMatch[3] ? joinMatch[3].toLowerCase() : joinMatch[2].toLowerCase(),
        condition: joinMatch[4].trim(),
        line: i + 1,
      });
      joinLines.push(i + 1);
    }
  }

  // Extract where clauses
  const whereClauses: ParsedQuery['whereClauses'] = [];
  if (whereStart !== -1) {
    let i = whereStart - 1;
    let whereText = lines[i].replace(/--.*$/, '').replace(/WHERE/i, '').trim();
    if (whereText) {
      whereClauses.push({ expression: whereText, line: i + 1 });
    }
    i++;
    while (i < lines.length) {
      const l = lines[i].replace(/--.*$/, '').trim();
      if (!l) {
        i++;
        continue;
      }
      const upper = l.toUpperCase();
      if (upper.startsWith('GROUP BY') || upper.startsWith('ORDER BY') || upper.startsWith('HAVING') || upper.startsWith('LIMIT')) {
        break;
      }
      if (upper.startsWith('AND ') || upper.startsWith('OR ')) {
        whereClauses.push({ expression: l.replace(/^(AND|OR)\s+/i, '').trim(), line: i + 1 });
      } else if (l.includes('=')) {
        whereClauses.push({ expression: l, line: i + 1 });
      }
      i++;
    }
  }

  // Extract select columns
  const selectColumns: ParsedQuery['selectColumns'] = [];
  let curLine = selectStart;
  while (curLine <= lines.length && curLine !== fromStart) {
    const l = lines[curLine - 1].replace(/--.*$/, '').replace(/SELECT/i, '').trim();
    if (l) {
      const parts = l.split(',');
      for (const p of parts) {
        const trimmed = p.trim();
        if (trimmed) {
          const aliasMatch = trimmed.match(/(.+)\s+AS\s+([a-zA-Z0-9_]+)/i);
          if (aliasMatch) {
            selectColumns.push({ name: aliasMatch[1].trim(), alias: aliasMatch[2].trim(), line: curLine });
          } else {
            selectColumns.push({ name: trimmed, line: curLine });
          }
        }
      }
    }
    curLine++;
  }

  return {
    parsed: {
      raw: queryText,
      selectColumns,
      fromTable,
      joins,
      whereClauses,
      groupByColumns: [],
      havingClauses: [],
      orderByColumns: [],
      lineMap: {
        selectLine: selectStart,
        fromLine: fromStart,
        whereLine: whereStart !== -1 ? whereStart : fromStart,
        joinLines,
        groupByLine: groupByStart !== -1 ? groupByStart : undefined,
        orderByLine: orderByStart !== -1 ? orderByStart : undefined,
      },
    },
  };
}

export function validateSparkQuery(queryText: string, validTables: string[]): ValidationResult {
  const { parsed, error } = parseSparkQuery(queryText);
  if (error || !parsed) {
    return {
      isValid: false,
      issues: [{ message: error || 'Failed to parse query', severity: 'error' }],
    };
  }

  const issues: ValidationResult['issues'] = [];

  // Validate primary table exists in catalog
  if (!validTables.includes(parsed.fromTable.name)) {
    issues.push({
      line: parsed.fromTable.line,
      message: `Table '${parsed.fromTable.name}' not found in Spark Catalog. Available tables: ${validTables.join(', ')}`,
      severity: 'error',
    });
  }

  // Validate joins
  for (const j of parsed.joins) {
    if (!validTables.includes(j.table)) {
      issues.push({
        line: j.line,
        message: `Joined table '${j.table}' not found in Spark Catalog. Available tables: ${validTables.join(', ')}`,
        severity: 'error',
      });
    }
    if (!j.condition) {
      issues.push({
        line: j.line,
        message: `Join condition missing for table '${j.table}'. Cross joins require explicit Cartesian product syntax.`,
        severity: 'warning',
      });
    }
  }

  return {
    isValid: issues.filter((i) => i.severity === 'error').length === 0,
    issues,
  };
}

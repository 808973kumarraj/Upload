import { SimulationTopic } from '../../types/simulation';
import { CatalystState } from '../../types/catalyst';
import { CATALYST_PRESETS } from './presets';
import { parseSparkQuery, validateSparkQuery } from './parser';
import { buildCatalystSnapshots, CatalystEngineParams } from './engine';
import { SPARK_CATALOG } from './catalog';

export const SPARK_CATALYST_TOPIC: SimulationTopic<CatalystState, string> = {
  id: 'spark_catalyst',
  name: 'Apache Spark Catalyst Query Optimizer',
  shortName: 'Spark Catalyst',
  category: 'Query Compilation & Distributed Engines',
  description: 'Deep interactive simulation of Apache Spark’s Catalyst query execution engine: AST parsing, Catalog analysis, rule-based logical optimization, physical planning (Broadcast vs Sort-Merge join), and Whole-Stage Java bytecode generation.',
  inputLanguage: 'sql',
  defaultCode: CATALYST_PRESETS[0].code,
  presets: CATALYST_PRESETS,
  parameters: [
    {
      id: 'autoBroadcastJoinThreshold',
      label: 'Broadcast Join Threshold',
      type: 'range',
      defaultValue: 10,
      min: 0,
      max: 50,
      step: 1,
      unit: 'MB',
      description: 'spark.sql.autoBroadcastJoinThreshold: Configures the maximum size in MB for a table that will be broadcast to all worker nodes. Setting to 0 disables broadcast and forces SortMergeJoin.',
      category: 'Physical Planning'
    },
    {
      id: 'enableCBO',
      label: 'Cost-Based Optimizer (CBO)',
      type: 'boolean',
      defaultValue: true,
      description: 'spark.sql.cbo.enabled: Enables table statistics collection, column histograms, and dynamic join reordering.',
      category: 'Cost Model'
    },
    {
      id: 'predicatePushdown',
      label: 'Predicate Pushdown',
      type: 'boolean',
      defaultValue: true,
      description: 'spark.sql.optimizer.predicatePushdown: Pushes filter conditions below joins directly into the storage scan (Parquet/Delta).',
      category: 'Logical Rules'
    },
    {
      id: 'columnPruning',
      label: 'Column Pruning',
      type: 'boolean',
      defaultValue: true,
      description: 'spark.sql.optimizer.columnPruning: Eliminates unreferenced columns from scan schemas to prevent reading unused data blocks.',
      category: 'Logical Rules'
    },
    {
      id: 'wholeStageCodegen',
      label: 'Whole-Stage Code Generation',
      type: 'boolean',
      defaultValue: true,
      description: 'spark.sql.codegen.wholeStage: Synthesizes a unified Java class compiled via Janino, eliminating virtual method invocations and running inside CPU registers.',
      category: 'Runtime / Tungsten'
    },
    {
      id: 'shufflePartitions',
      label: 'Shuffle Partitions',
      type: 'select',
      defaultValue: 200,
      options: [
        { label: '5 Partitions (Development)', value: 5 },
        { label: '200 Partitions (Default Spark)', value: 200 },
        { label: '500 Partitions (High Scale)', value: 500 },
      ],
      description: 'spark.sql.shuffle.partitions: Number of partitions to use when shuffling data for joins or aggregations.',
      category: 'Physical Planning'
    },
    {
      id: 'customersTableSizeMB',
      label: 'Customers Table Size',
      type: 'range',
      defaultValue: 8,
      min: 1,
      max: 50,
      step: 1,
      unit: 'MB',
      description: 'Simulated data size of the customers table. Adjusting above the broadcast threshold triggers SortMergeJoin.',
      category: 'Data Sizing'
    },
    {
      id: 'ordersTableSizeMB',
      label: 'Orders Table Size',
      type: 'range',
      defaultValue: 450,
      min: 50,
      max: 1000,
      step: 25,
      unit: 'MB',
      description: 'Simulated data size of the orders fact table.',
      category: 'Data Sizing'
    },
  ],
  metrics: [
    {
      id: 'estimatedLatencyMs',
      label: 'Est. Query Latency',
      unit: 'ms',
      format: 'duration',
      description: 'Estimated end-to-end execution time on a 16-core Spark cluster.',
      isKeyMetric: true,
    },
    {
      id: 'shuffleVolumeMB',
      label: 'Shuffle Read/Write',
      unit: 'MB',
      format: 'bytes',
      description: 'Total data redistributed across worker network interfaces.',
      isKeyMetric: true,
    },
    {
      id: 'shuffleExchanges',
      label: 'Network Shuffle Stages',
      unit: 'stages',
      format: 'count',
      description: 'Number of ShuffleExchangeExec boundary operators introduced into the physical plan.',
      isKeyMetric: true,
    },
    {
      id: 'scannedRows',
      label: 'Scanned Rows',
      format: 'number',
      description: 'Total rows read from underlying storage after predicate pushdown evaluation.',
    },
    {
      id: 'projectedMemoryMB',
      label: 'Peak Working Memory',
      unit: 'MB',
      format: 'bytes',
      description: 'Peak memory occupied by broadcast hash tables, sort buffers, and Tungsten unsafe rows.',
    },
    {
      id: 'appliedRulesCount',
      label: 'Rules Evaluated',
      format: 'count',
      description: 'Number of pattern-matching transformation rules executed by Catalyst RuleExecutor.',
    },
    {
      id: 'codegenLines',
      label: 'Generated Java Lines',
      format: 'count',
      description: 'Lines of synthesized Janino Java code in the active WholeStageCodegen stage.',
    },
    {
      id: 'planningTimeMs',
      label: 'Catalyst Planning Time',
      unit: 'ms',
      format: 'duration',
      description: 'CPU time spent by driver traversing and optimizing the query tree.',
    }
  ],
  docs: {
    overview: 'Apache Spark Catalyst is an extensible query optimization framework built on Scala functional programming. It transforms relational queries into highly optimized physical execution code through four consecutive phases: Analysis, Logical Optimization, Physical Planning, and Code Generation.',
    inputs: 'Accepts Spark SQL queries or DataFrame operational chains. You can customize table references, predicates, joins, and tune configuration parameters such as autoBroadcastJoinThreshold and wholeStageCodegen.',
    executionModel: 'Catalyst represents queries as abstract syntax trees (ASTs) of TreeNode subclasses. A RuleExecutor applies batches of transformation rules using pattern matching until a fixed-point (idempotence) is reached.',
    importantConcepts: [
      'Unresolved vs Resolved Plan: Attributes and relations lack types and identities until resolved against the SessionCatalog.',
      'Rule-Based Optimization (RBO): Applies deterministic transformation rules such as PushDownPredicate, ColumnPruning, ConstantFolding, and NullPropagation.',
      'Cost-Based Optimization (CBO): Uses table and column statistics to reorder joins and calculate physical operator costs.',
      'BroadcastHashJoin vs SortMergeJoin: Small tables (<= threshold) are broadcast to bypass expensive network shuffles entirely.',
      'Project Tungsten & WholeStageCodegen: Janino in-memory compiler synthesizes custom Java bytecode, eliminating JVM virtual function calls and keeping variables in CPU registers.'
    ],
    performanceImplications: 'Enabling Predicate Pushdown skips irrelevant Parquet blocks at the disk level. Proper broadcast thresholds prevent gigabytes of shuffle network saturation and expensive disk spills.',
    simulationNotes: 'This simulator faithfully models the four architectural phases, rule applications, physical strategy choices, RDD stage DAGs, and synthesized Janino Java bytecode of Apache Spark 3.x.'
  },

  parse: (input: string) => {
    const res = parseSparkQuery(input);
    return { ast: res.parsed, error: res.error };
  },

  validate: (input: string) => {
    return validateSparkQuery(input, Object.keys(SPARK_CATALOG));
  },

  buildExecutionPlan: (input: string, params: Record<string, any>) => {
    const { parsed } = parseSparkQuery(input);
    const safeParsed = parsed || parseSparkQuery(CATALYST_PRESETS[0].code).parsed!;
    const engineParams: CatalystEngineParams = {
      autoBroadcastJoinThreshold: params.autoBroadcastJoinThreshold ?? 10,
      enableCBO: params.enableCBO ?? true,
      predicatePushdown: params.predicatePushdown ?? true,
      columnPruning: params.columnPruning ?? true,
      wholeStageCodegen: params.wholeStageCodegen ?? true,
      shufflePartitions: params.shufflePartitions ?? 200,
      customersTableSizeMB: params.customersTableSizeMB ?? 8,
      ordersTableSizeMB: params.ordersTableSizeMB ?? 450,
    };

    const steps = buildCatalystSnapshots(safeParsed, engineParams, 'DEFAULT');
    return {
      steps,
      totalSteps: steps.length,
    };
  }
};

import { ScenarioPreset } from '../../types/simulation';

export const CATALYST_PRESETS: ScenarioPreset[] = [
  {
    id: 'preset_filter_pushdown_broadcast',
    name: 'Filter Pushdown & Broadcast Join (Classic)',
    description: 'Demonstrates pushdown of filter predicates into Parquet scan and conversion of large shuffle to BroadcastHashJoin.',
    code: `-- Scenario 1: E-Commerce Customer & Orders Analysis
-- Target: Fast analytical join with selective filtering
SELECT 
    c.customer_id,
    c.customer_name,
    c.tier,
    o.order_id,
    o.order_amount,
    o.order_date
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
WHERE o.order_amount > 250.00
  AND c.tier = 'PLATINUM'
  AND o.order_date >= '2024-01-01'
ORDER BY o.order_amount DESC;`,
    parameters: {
      autoBroadcastJoinThreshold: 10,
      enableCBO: true,
      predicatePushdown: true,
      columnPruning: true,
      wholeStageCodegen: true,
      shufflePartitions: 200,
      customersTableSizeMB: 8,
      ordersTableSizeMB: 450,
    }
  },
  {
    id: 'preset_sort_merge_join',
    name: 'Large Dataset Sort-Merge Join (Shuffle Stages)',
    description: 'When both tables exceed the broadcast threshold, Catalyst introduces ShuffleExchange and Sort operators.',
    code: `-- Scenario 2: Large Scale Financial Transactions Join
-- Both tables exceed autoBroadcastJoinThreshold -> Triggers SortMergeJoin
SELECT 
    t.transaction_id,
    t.account_id,
    t.amount,
    a.account_type,
    a.risk_score
FROM transactions t
JOIN accounts a ON t.account_id = a.account_id
WHERE t.amount > 1000.00
  AND a.status = 'ACTIVE';`,
    parameters: {
      autoBroadcastJoinThreshold: 10,
      enableCBO: true,
      predicatePushdown: true,
      columnPruning: true,
      wholeStageCodegen: true,
      shufflePartitions: 200,
      customersTableSizeMB: 120,
      ordersTableSizeMB: 850,
    }
  },
  {
    id: 'preset_constant_folding',
    name: 'Constant Folding & Expression Simplification',
    description: 'Shows compile-time evaluation of constant arithmetic, static booleans, and branch elimination.',
    code: `-- Scenario 3: Expression Optimization & Dead Code Pruning
-- Evaluates constant math and redundant conditions at plan-time
SELECT 
    o.order_id,
    o.order_amount * (1.0 - 0.15) AS discounted_amount,
    o.order_date
FROM orders o
WHERE o.status = 'COMPLETED'
  AND (100 * 24 * 60) > 10000
  AND 1 = 1
  AND (o.tax_rate + 0.05) > 0.10;`,
    parameters: {
      autoBroadcastJoinThreshold: 10,
      enableCBO: true,
      predicatePushdown: true,
      columnPruning: true,
      wholeStageCodegen: true,
      shufflePartitions: 200,
      customersTableSizeMB: 10,
      ordersTableSizeMB: 300,
    }
  },
  {
    id: 'preset_aggregation_skew',
    name: 'HashAggregate & Shuffle Partitions',
    description: 'Illustrates two-phase aggregation (partial aggregate on mapper, final aggregate after shuffle exchange).',
    code: `-- Scenario 4: High-Cardinality Regional Sales Rollup
-- Uses HashAggregate with map-side partial aggregation
SELECT 
    o.region,
    COUNT(o.order_id) AS total_orders,
    SUM(o.order_amount) AS gross_revenue,
    AVG(o.order_amount) AS avg_order_value
FROM orders o
WHERE o.order_date >= '2024-01-01'
GROUP BY o.region
HAVING SUM(o.order_amount) > 50000;`,
    parameters: {
      autoBroadcastJoinThreshold: 10,
      enableCBO: true,
      predicatePushdown: true,
      columnPruning: true,
      wholeStageCodegen: true,
      shufflePartitions: 200,
      customersTableSizeMB: 10,
      ordersTableSizeMB: 500,
    }
  },
  {
    id: 'preset_three_way_join_cbo',
    name: '3-Way Join Reordering with CBO',
    description: 'Cost-Based Optimizer utilizes table statistics and histograms to reorder join sequence for minimal intermediate volume.',
    code: `-- Scenario 5: Multi-table Order Fulfillment Pipeline
-- CBO reorders joins: small table filtered first to minimize intermediate rows
SELECT 
    c.customer_name,
    p.product_name,
    o.order_amount,
    o.quantity
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
JOIN products p ON o.product_id = p.product_id
WHERE c.country = 'USA'
  AND p.category = 'Electronics';`,
    parameters: {
      autoBroadcastJoinThreshold: 10,
      enableCBO: true,
      predicatePushdown: true,
      columnPruning: true,
      wholeStageCodegen: true,
      shufflePartitions: 200,
      customersTableSizeMB: 12,
      ordersTableSizeMB: 600,
    }
  }
];

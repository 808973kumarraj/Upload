import { PlanNode, CatalystState, RDDStage } from '../../types/catalyst';
import { SimulationSnapshot, SimulationEvent, StepExplanation } from '../../types/simulation';
import { ParsedQuery } from './parser';
import { SPARK_CATALOG } from './catalog';
import { generateJaninoJavaCode } from './codegen';

export interface CatalystEngineParams {
  autoBroadcastJoinThreshold: number; // in MB
  enableCBO: boolean;
  predicatePushdown: boolean;
  columnPruning: boolean;
  wholeStageCodegen: boolean;
  shufflePartitions: number;
  customersTableSizeMB: number;
  ordersTableSizeMB: number;
}

export function buildCatalystSnapshots(
  parsed: ParsedQuery,
  params: CatalystEngineParams,
  mode: 'DEFAULT' | 'CUSTOM'
): SimulationSnapshot<CatalystState>[] {
  const snapshots: SimulationSnapshot<CatalystState>[] = [];

  const table1Name = parsed.fromTable.name in SPARK_CATALOG ? parsed.fromTable.name : 'customers';
  const table2Name = parsed.joins[0]?.table in SPARK_CATALOG ? parsed.joins[0].table : 'orders';

  const t1Meta = SPARK_CATALOG[table1Name] || SPARK_CATALOG['customers'];
  const t2Meta = SPARK_CATALOG[table2Name] || SPARK_CATALOG['orders'];

  // Calculate actual sizes based on parameters if matching
  const t1SizeMB = table1Name === 'customers' ? params.customersTableSizeMB : Math.round(t1Meta.sizeBytes / (1024 * 1024));
  const t2SizeMB = table2Name === 'orders' ? params.ordersTableSizeMB : Math.round(t2Meta.sizeBytes / (1024 * 1024));

  // Determine join strategy: Broadcast if smaller table is <= threshold
  const minTableSizeMB = Math.min(t1SizeMB, t2SizeMB);
  const canBroadcast = minTableSizeMB <= params.autoBroadcastJoinThreshold;
  const joinType = canBroadcast ? 'BroadcastHashJoin' : 'SortMergeJoin';

  // Base raw rows
  const initialRowsTable1 = t1Meta.rowCount;
  const initialRowsTable2 = t2Meta.rowCount;
  const filteredRowsTable2 = params.predicatePushdown ? Math.round(initialRowsTable2 * 0.12) : initialRowsTable2;

  // STEP 0: Unresolved Logical Plan
  const step0Root: PlanNode = {
    id: 'unresolved_project',
    type: 'Project',
    name: 'UnresolvedProject',
    title: 'Project [unresolved]',
    details: 'SELECT ' + parsed.selectColumns.map(c => c.name).join(', '),
    outputColumns: parsed.selectColumns.map(c => c.name),
    children: [
      {
        id: 'unresolved_filter',
        type: 'Filter',
        name: 'UnresolvedFilter',
        title: 'Filter [unresolved]',
        details: parsed.whereClauses.map(w => w.expression).join(' AND ') || 'o.order_amount > 250.00',
        children: [
          {
            id: 'unresolved_join',
            type: 'Join',
            name: 'UnresolvedJoin',
            title: 'Join [unresolved]',
            details: `Inner Join on ${parsed.joins[0]?.condition || 'c.customer_id = o.customer_id'}`,
            children: [
              {
                id: 'unresolved_rel_1',
                type: 'UnresolvedRelation',
                name: 'UnresolvedRelation',
                title: `UnresolvedRelation [${table1Name}]`,
                details: `Table reference: ${table1Name} (Catalog lookup required)`,
                children: [],
              },
              {
                id: 'unresolved_rel_2',
                type: 'UnresolvedRelation',
                name: 'UnresolvedRelation',
                title: `UnresolvedRelation [${table2Name}]`,
                details: `Table reference: ${table2Name} (Catalog lookup required)`,
                children: [],
              }
            ]
          }
        ]
      }
    ]
  };

  const step0State: CatalystState = {
    phase: 'unresolved_logical',
    phaseIndex: 0,
    totalPhases: 5,
    rootNode: step0Root,
    stages: [],
    generatedCode: '// Java code generation occurs during Phase 5 (WholeStageCodegen)',
    ruleApplications: [],
    tableMetadata: {
      [table1Name]: { ...t1Meta, sizeBytes: t1SizeMB * 1024 * 1024 },
      [table2Name]: { ...t2Meta, sizeBytes: t2SizeMB * 1024 * 1024 },
    },
    activeRule: {
      name: 'SqlBaseParser (Antlr4)',
      description: 'Parses raw SQL text into an Abstract Syntax Tree (AST) of Unresolved operators.',
      scalaRule: 'org.apache.spark.sql.execution.SparkSqlParser',
      beforeSummary: 'Raw SQL text received by SparkSession',
      afterSummary: 'Tree of UnresolvedRelation and UnresolvedAttribute nodes'
    }
  };

  const step0Event: SimulationEvent = {
    id: 'evt_0',
    step: 0,
    timestamp: '00:00:01.012',
    type: 'PARSING',
    label: 'Query Parsed into AST',
    description: 'Antlr4 parser generated Unresolved Logical Plan with placeholder relations and attributes.',
    sourceLine: parsed.lineMap.selectLine,
    phase: 'Unresolved Logical Plan',
    impact: 'neutral',
  };

  const step0Explanation: StepExplanation = {
    step: 0,
    phase: 'Phase 1: Parse & AST Generation',
    title: 'Unresolved Logical Plan Created',
    whatHappened: 'The query was parsed from plain text into an abstract syntax tree composed of Unresolved Logical Plan nodes.',
    whyItHappened: 'Before Catalyst can optimize or execute a query, it must represent its relational algebra operations (Project, Filter, Join, Relation) as an in-memory tree data structure.',
    underlyingMechanism: 'Spark uses ANTLR4 grammar (SqlBase.g4) to tokenize keywords and build TreeNode objects. Attributes are wrapped in UnresolvedAttribute, and table names are placed in UnresolvedRelation because Spark does not yet know if the tables exist or what data types they hold.',
    consequences: 'No disk I/O or cluster communication has occurred. Schema, column types, and semantic validity remain completely unbound.',
    depths: {
      beginner: 'Spark read your SQL query and turned it into an outline of operations, but it has not checked if the tables or columns really exist yet.',
      technical: 'Parsed tokens into an Abstract Syntax Tree of Catalyst TreeNode subclasses. Nodes hold string identifiers without schema binding or catalog resolution.',
      internals: 'Antlr4 parser instantiated AstBuilder which visited grammar rules to produce LogicalPlan instances: Project(Filter(Join(UnresolvedRelation, UnresolvedRelation))). UnresolvedAttributes lack ExprId identifiers.',
    }
  };

  snapshots.push({
    step: 0,
    mode,
    state: step0State,
    metrics: {
      planningTimeMs: 1.2,
      projectedMemoryMB: t1SizeMB + t2SizeMB,
      shuffleVolumeMB: 0,
      shuffleExchanges: 0,
      scannedRows: initialRowsTable1 + initialRowsTable2,
      appliedRulesCount: 0,
      codegenLines: 0,
      estimatedLatencyMs: 1450,
    },
    activeLine: parsed.lineMap.selectLine,
    event: step0Event,
    explanation: step0Explanation,
  });

  // STEP 1: Analysis & Catalog Resolution
  const step1Root: PlanNode = {
    id: 'analyzed_project',
    type: 'Project',
    name: 'Project',
    title: 'Project [Resolved]',
    details: 'c.customer_id#1L, c.customer_name#2, c.tier#3, o.order_id#10L, o.order_amount#13, o.order_date#14',
    schema: [
      { name: 'customer_id', dataType: 'LongType' },
      { name: 'customer_name', dataType: 'StringType' },
      { name: 'tier', dataType: 'StringType' },
      { name: 'order_id', dataType: 'LongType' },
      { name: 'order_amount', dataType: 'DecimalType(10,2)' },
      { name: 'order_date', dataType: 'DateType' }
    ],
    children: [
      {
        id: 'analyzed_filter',
        type: 'Filter',
        name: 'Filter',
        title: 'Filter [Resolved]',
        details: 'o.order_amount#13 > 250.00 AND c.tier#3 = "PLATINUM"',
        children: [
          {
            id: 'analyzed_join',
            type: 'Join',
            name: 'Join',
            title: 'Join [Resolved]',
            details: 'Inner Join (c.customer_id#1L = o.customer_id#11L)',
            children: [
              {
                id: 'resolved_rel_1',
                type: 'LogicalRelation',
                name: 'LogicalRelation',
                title: `LogicalRelation [${table1Name}]`,
                details: `Catalog: gold.${table1Name} (${t1Meta.fileFormat})`,
                schema: t1Meta.schema,
                children: [],
              },
              {
                id: 'resolved_rel_2',
                type: 'LogicalRelation',
                name: 'LogicalRelation',
                title: `LogicalRelation [${table2Name}]`,
                details: `Catalog: gold.${table2Name} (${t2Meta.fileFormat})`,
                schema: t2Meta.schema,
                children: [],
              }
            ]
          }
        ]
      }
    ]
  };

  const step1Event: SimulationEvent = {
    id: 'evt_1',
    step: 1,
    timestamp: '00:00:01.048',
    type: 'ANALYSIS',
    label: 'Catalog Resolution & Type Binding',
    description: 'Spark Metastore catalog lookup completed. Table schemas resolved and column data types verified.',
    sourceLine: parsed.lineMap.fromLine,
    phase: 'Analyzed Logical Plan',
    impact: 'neutral',
  };

  const step1Explanation: StepExplanation = {
    step: 1,
    phase: 'Phase 2: Analysis & Catalog Lookup',
    title: 'Analyzed Logical Plan Resolved',
    whatHappened: 'The Analyzer resolved all table references against the Spark Metastore / SessionCatalog and assigned unique Expression IDs (`#exprId`) and data types to all attributes.',
    whyItHappened: 'Without knowing column data types and nullability, Spark cannot verify mathematical comparisons, type coercions, or validate whether a join condition is valid.',
    underlyingMechanism: 'The Analyzer executes a batch of rules using `SessionCatalog`. It matches `UnresolvedRelation` to physical tables/views, pulls table metadata, and transforms `UnresolvedAttribute` into `AttributeReference` bound to schema positions with verified datatypes.',
    consequences: 'Semantic correctness is guaranteed. If a column or table had been missing, Spark would fail here with an `AnalysisException`.',
    depths: {
      beginner: 'Spark checked its database catalog, confirmed the tables exist, and learned what kinds of data (numbers, dates, text) each column holds.',
      technical: 'Analyzer applied `ResolveRelations`, `ResolveReferences`, and `TypeCoercion` batches. Assigned monotonically increasing integer Expression IDs (e.g. `customer_id#1L`).',
      internals: 'Traversed plan with `RuleExecutor[LogicalPlan]`. Looked up Hive Metastore/In-Memory Catalog to instantiate `LogicalRelation(HadoopFsRelation)`. Verified expression signatures and column existence.',
    }
  };

  snapshots.push({
    step: 1,
    mode,
    state: {
      ...step0State,
      phase: 'analyzed_logical',
      phaseIndex: 1,
      rootNode: step1Root,
      previousRootNode: step0Root,
      ruleApplications: [
        { ruleName: 'ResolveRelations', timeMs: 14, affectedNode: 'LogicalRelation', description: 'Resolved table references against SessionCatalog' },
        { ruleName: 'ResolveReferences', timeMs: 11, affectedNode: 'AttributeReference', description: 'Bound column names to schema attribute IDs' },
      ],
      activeRule: {
        name: 'Analyzer.ResolveRelations & ResolveReferences',
        description: 'Binds catalog schema metadata and assigns unique Expression IDs.',
        scalaRule: 'org.apache.spark.sql.catalyst.analysis.Analyzer',
        beforeSummary: 'UnresolvedRelation("customers")',
        afterSummary: 'LogicalRelation(customers, [customer_id#1L, ...])'
      }
    },
    metrics: {
      planningTimeMs: 4.8,
      projectedMemoryMB: t1SizeMB + t2SizeMB,
      shuffleVolumeMB: 0,
      shuffleExchanges: 0,
      scannedRows: initialRowsTable1 + initialRowsTable2,
      appliedRulesCount: 4,
      codegenLines: 0,
      estimatedLatencyMs: 1420,
    },
    activeLine: parsed.lineMap.fromLine,
    event: step1Event,
    explanation: step1Explanation,
  });

  // STEP 2: Logical Optimization - Rule: PushDownPredicate
  const step2Root: PlanNode = {
    id: 'opt_project',
    type: 'Project',
    name: 'Project',
    title: 'Project',
    details: 'c.customer_id#1L, c.customer_name#2, o.order_id#10L, o.order_amount#13',
    children: [
      {
        id: 'opt_join',
        type: 'Join',
        name: 'Join',
        title: 'Join [Pushed Filters]',
        details: 'Inner Join (c.customer_id#1L = o.customer_id#11L)',
        isTransformed: true,
        transformationBadge: 'Join Input Pruned',
        children: [
          {
            id: 'filter_c',
            type: 'Filter',
            name: 'Filter',
            title: 'Filter (c.tier#3 = "PLATINUM")',
            details: 'Pushed down: Filters customers BEFORE join',
            isTransformed: true,
            transformationBadge: 'Pushed Filter',
            children: [
              {
                id: 'rel_c',
                type: 'LogicalRelation',
                name: 'LogicalRelation',
                title: `LogicalRelation [${table1Name}]`,
                details: `Scan ${table1Name}`,
                pushedFilters: ["IsNotNull(customer_id)", "tier = 'PLATINUM'"],
                children: []
              }
            ]
          },
          {
            id: 'filter_o',
            type: 'Filter',
            name: 'Filter',
            title: 'Filter (o.order_amount#13 > 250.00)',
            details: 'Pushed down: Filters orders BEFORE join',
            isTransformed: true,
            transformationBadge: 'Pushed Filter',
            children: [
              {
                id: 'rel_o',
                type: 'LogicalRelation',
                name: 'LogicalRelation',
                title: `LogicalRelation [${table2Name}]`,
                details: `Scan ${table2Name}`,
                pushedFilters: ["IsNotNull(customer_id)", "order_amount > 250.00", "order_date >= '2024-01-01'"],
                children: []
              }
            ]
          }
        ]
      }
    ]
  };

  const step2Event: SimulationEvent = {
    id: 'evt_2',
    step: 2,
    timestamp: '00:00:01.092',
    type: 'OPTIMIZATION',
    label: 'Rule Applied: PushDownPredicate',
    description: params.predicatePushdown
      ? 'Filter conditions pushed below Join into table scan operators, filtering rows before join processing.'
      : 'Predicate pushdown disabled via parameter flag.',
    sourceLine: parsed.lineMap.whereLine,
    phase: 'Optimized Logical Plan',
    impact: 'optimization',
  };

  const step2Explanation: StepExplanation = {
    step: 2,
    phase: 'Phase 3: Logical Optimization',
    title: 'Rule: PushDownPredicate Applied',
    whatHappened: params.predicatePushdown
      ? 'Catalyst pushed the WHERE filter predicates (`order_amount > 250` and `tier = "PLATINUM"`) through the Join operator directly onto the source table scans.'
      : 'Predicate pushdown was disabled by user configuration, forcing full table scans into the join.',
    whyItHappened: 'Filtering before a join drastically reduces the number of candidate tuples entering the join, avoiding wasteful CPU and memory costs.',
    underlyingMechanism: 'Catalyst’s `PushDownPredicate` rule inspects the filter expression tree. Any predicate whose referenced attributes originate strictly from one side of the join is safely transformed down below the Join operator.',
    consequences: `Reduces scanned records from ${(initialRowsTable1 + initialRowsTable2).toLocaleString()} down to ${(Math.round(initialRowsTable1 * 0.15) + filteredRowsTable2).toLocaleString()} rows (${Math.round((1 - (filteredRowsTable2 / initialRowsTable2)) * 100)}% data reduction before join).`,
    depths: {
      beginner: 'Instead of joining millions of rows and filtering afterwards, Spark filters the data right as it is read, throwing away 85% of irrelevant rows before joining.',
      technical: 'RuleExecutor invoked `PushDownPredicate`. Predicates partitioned by deterministic attribute dependency. Pushed conjuncts to left/right branches of the Join.',
      internals: 'Expression tree matched `Filter(condition, Join(left, right, Inner, joinCond))`. Condition split into deterministic conjuncts via `splitConjunctivePredicates`. Sub-expressions with `expr.references.subsetOf(left.outputSet)` moved to left child.',
    }
  };

  snapshots.push({
    step: 2,
    mode,
    state: {
      ...step0State,
      phase: 'optimized_logical',
      phaseIndex: 2,
      rootNode: step2Root,
      previousRootNode: step1Root,
      ruleApplications: [
        { ruleName: 'PushDownPredicate', timeMs: 8, affectedNode: 'Filter / Scan', description: 'Moved predicates below Join node' },
      ],
      activeRule: {
        name: 'org.apache.spark.sql.catalyst.optimizer.PushDownPredicate',
        description: 'Transforms Filter(condition, Join) into Join(Filter(left), Filter(right)).',
        scalaRule: 'PushDownPredicate',
        beforeSummary: 'Filter applied AFTER Join',
        afterSummary: 'Filters pushed BEFORE Join directly into leaf scans'
      }
    },
    metrics: {
      planningTimeMs: 8.5,
      projectedMemoryMB: params.predicatePushdown ? Math.round(t1SizeMB * 0.3 + t2SizeMB * 0.2) : t1SizeMB + t2SizeMB,
      shuffleVolumeMB: 0,
      shuffleExchanges: 0,
      scannedRows: params.predicatePushdown ? Math.round(initialRowsTable1 * 0.2) + filteredRowsTable2 : initialRowsTable1 + initialRowsTable2,
      appliedRulesCount: 8,
      codegenLines: 0,
      estimatedLatencyMs: params.predicatePushdown ? 680 : 1420,
    },
    activeLine: parsed.lineMap.whereLine,
    event: step2Event,
    explanation: step2Explanation,
  });

  // STEP 3: Logical Optimization - Rule: ColumnPruning & ConstantFolding
  const step3Root: PlanNode = {
    ...step2Root,
    transformationBadge: 'Columns Pruned',
    children: [
      {
        ...step2Root.children[0],
        children: [
          {
            ...step2Root.children[0].children[0],
            details: 'Pushed Project: [customer_id#1L, customer_name#2, tier#3] (country, signup_date pruned)',
          },
          {
            ...step2Root.children[0].children[1],
            details: 'Pushed Project: [order_id#10L, customer_id#11L, order_amount#13] (tax_rate, region pruned)',
          }
        ]
      }
    ]
  };

  const step3Event: SimulationEvent = {
    id: 'evt_3',
    step: 3,
    timestamp: '00:00:01.120',
    type: 'OPTIMIZATION',
    label: 'Rule Applied: ColumnPruning & ConstantFolding',
    description: 'Pruned 8 unused columns from disk readers and simplified constant arithmetic at plan time.',
    sourceLine: parsed.lineMap.selectLine,
    phase: 'Optimized Logical Plan',
    impact: 'cost_reduction',
  };

  const step3Explanation: StepExplanation = {
    step: 3,
    phase: 'Phase 3: Logical Optimization',
    title: 'ColumnPruning & ConstantFolding Applied',
    whatHappened: 'Catalyst analyzed the downstream column dependencies and pruned unreferenced columns (`country`, `signup_date`, `tax_rate`, `region`) so they will not be read from disk.',
    whyItHappened: 'Parquet and ORC formats store data in column-oriented chunks. If a column is omitted from the scan projection, the storage engine completely skips reading its disk blocks.',
    underlyingMechanism: '`ColumnPruning` traverses from root to leaf, collecting the `references` set of required attributes. Any attribute not in the required set is dropped from the scan output schema.',
    consequences: 'Disk I/O bandwidth reduced by ~55%. Memory footprint of deserialized rows halved.',
    depths: {
      beginner: 'Spark saw you only asked for 6 columns, so it told the storage engine to ignore the other columns on disk completely, saving disk speed and RAM.',
      technical: 'RuleExecutor evaluated `ColumnPruning`. Attribute sets propagated bottom-up to prune `LogicalRelation.output`. Pruning instructions forwarded to `FileSourceScanExec`.',
      internals: 'Invoked `org.apache.spark.sql.catalyst.optimizer.ColumnPruning`. Pruned attributes removed from `HadoopFsRelation.dataSchema` to generate `requiredSchema`.',
    }
  };

  snapshots.push({
    step: 3,
    mode,
    state: {
      ...step0State,
      phase: 'optimized_logical',
      phaseIndex: 2,
      rootNode: step3Root,
      previousRootNode: step2Root,
      ruleApplications: [
        { ruleName: 'PushDownPredicate', timeMs: 8, affectedNode: 'Filter', description: 'Moved filter below join' },
        { ruleName: 'ColumnPruning', timeMs: 6, affectedNode: 'Project', description: 'Eliminated 8 unneeded columns' },
        { ruleName: 'ConstantFolding', timeMs: 3, affectedNode: 'Expression', description: 'Pre-evaluated static mathematical operations' },
      ],
      activeRule: {
        name: 'org.apache.spark.sql.catalyst.optimizer.ColumnPruning',
        description: 'Eliminates unreferenced schema attributes from leaf storage scans.',
        scalaRule: 'ColumnPruning',
        beforeSummary: 'All 14 columns retained in scan schema',
        afterSummary: 'Only 6 referenced columns requested from Parquet vectorized reader'
      }
    },
    metrics: {
      planningTimeMs: 12.1,
      projectedMemoryMB: Math.round(t1SizeMB * 0.2 + t2SizeMB * 0.15),
      shuffleVolumeMB: 0,
      shuffleExchanges: 0,
      scannedRows: params.predicatePushdown ? Math.round(initialRowsTable1 * 0.2) + filteredRowsTable2 : initialRowsTable1 + initialRowsTable2,
      appliedRulesCount: 14,
      codegenLines: 0,
      estimatedLatencyMs: params.predicatePushdown ? 490 : 1100,
    },
    activeLine: parsed.lineMap.selectLine,
    event: step3Event,
    explanation: step3Explanation,
  });

  // STEP 4: Physical Planning - Strategy Selection (Broadcast vs SortMerge)
  const isBroadcastSelected = canBroadcast;

  const physicalJoinNode: PlanNode = isBroadcastSelected
    ? {
        id: 'broadcast_hash_join',
        type: 'BroadcastHashJoin',
        name: 'BroadcastHashJoinExec',
        title: 'BroadcastHashJoin [BuildRight / BuildLeft]',
        details: `Build Side: ${table1Name} (${t1SizeMB} MB <= ${params.autoBroadcastJoinThreshold} MB threshold) • No Network Shuffle required!`,
        isTransformed: true,
        transformationBadge: 'Broadcast Hash Join',
        children: [
          {
            id: 'scan_orders',
            type: 'FileSourceScan',
            name: 'FileSourceScanExec',
            title: `FileScan parquet ${table2Name}`,
            details: `Batched: true, PushedFilters: [IsNotNull, amount > 250], Rows: ${(filteredRowsTable2).toLocaleString()}`,
            children: []
          },
          {
            id: 'broadcast_exchange',
            type: 'BroadcastExchange',
            name: 'BroadcastExchangeExec',
            title: 'BroadcastExchangeExec [HashedRelation]',
            details: `TorrentBroadcast of ${table1Name} (${t1SizeMB} MB) to all worker nodes`,
            children: [
              {
                id: 'scan_customers',
                type: 'FileSourceScan',
                name: 'FileSourceScanExec',
                title: `FileScan parquet ${table1Name}`,
                details: `PushedFilters: [tier = 'PLATINUM'], Rows: ${(Math.round(initialRowsTable1 * 0.15)).toLocaleString()}`,
                children: []
              }
            ]
          }
        ]
      }
    : {
        id: 'sort_merge_join',
        type: 'SortMergeJoin',
        name: 'SortMergeJoinExec',
        title: 'SortMergeJoinExec',
        details: `Both tables exceed ${params.autoBroadcastJoinThreshold} MB threshold (${t1SizeMB} MB & ${t2SizeMB} MB) -> Requires Shuffle & Sort`,
        isTransformed: true,
        transformationBadge: 'SortMergeJoin (Shuffled)',
        children: [
          {
            id: 'sort_orders',
            type: 'Sort',
            name: 'SortExec',
            title: 'SortExec [customer_id ASC]',
            details: 'In-memory radix sort on join key before stream merge',
            children: [
              {
                id: 'shuffle_orders',
                type: 'ShuffleExchange',
                name: 'ShuffleExchangeExec',
                title: `ShuffleExchangeExec [hashpartitioning, ${params.shufflePartitions} parts]`,
                details: `Network shuffle of orders across ${params.shufflePartitions} partitions`,
                children: [
                  {
                    id: 'scan_orders_smj',
                    type: 'FileSourceScan',
                    name: 'FileSourceScanExec',
                    title: `FileScan parquet ${table2Name}`,
                    details: `PushedFilters: [order_amount > 250]`,
                    children: []
                  }
                ]
              }
            ]
          },
          {
            id: 'sort_cust',
            type: 'Sort',
            name: 'SortExec',
            title: 'SortExec [customer_id ASC]',
            details: 'In-memory sort on join key',
            children: [
              {
                id: 'shuffle_cust',
                type: 'ShuffleExchange',
                name: 'ShuffleExchangeExec',
                title: `ShuffleExchangeExec [hashpartitioning, ${params.shufflePartitions} parts]`,
                details: `Network shuffle of customers across ${params.shufflePartitions} partitions`,
                children: [
                  {
                    id: 'scan_cust_smj',
                    type: 'FileSourceScan',
                    name: 'FileSourceScanExec',
                    title: `FileScan parquet ${table1Name}`,
                    details: `PushedFilters: [tier = 'PLATINUM']`,
                    children: []
                  }
                ]
              }
            ]
          }
        ]
      };

  const step4Root: PlanNode = {
    id: 'physical_root',
    type: 'Project',
    name: 'ProjectExec',
    title: 'ProjectExec [Tungsten UnsafeRow]',
    details: 'Materializes projection columns into UnsafeRow format',
    children: [physicalJoinNode]
  };

  const step4Event: SimulationEvent = {
    id: 'evt_4',
    step: 4,
    timestamp: '00:00:01.180',
    type: 'PLANNING',
    label: isBroadcastSelected ? 'Physical Plan: BroadcastHashJoin Selected' : 'Physical Plan: SortMergeJoin Selected',
    description: isBroadcastSelected
      ? `Table size (${minTableSizeMB} MB) is <= threshold (${params.autoBroadcastJoinThreshold} MB). BroadcastHashJoin chosen, eliminating cluster shuffle!`
      : `Table size (${minTableSizeMB} MB) exceeds threshold (${params.autoBroadcastJoinThreshold} MB). SortMergeJoin chosen with ${params.shufflePartitions} shuffle partitions.`,
    sourceLine: parsed.lineMap.joinLines[0] || parsed.lineMap.fromLine,
    phase: 'Physical Planning',
    impact: isBroadcastSelected ? 'optimization' : 'warning',
  };

  const step4Explanation: StepExplanation = {
    step: 4,
    phase: 'Phase 4: Physical Planning & Cost Model',
    title: isBroadcastSelected ? 'BroadcastHashJoin Strategy Selected' : 'SortMergeJoin Strategy Selected',
    whatHappened: isBroadcastSelected
      ? `Catalyst selected BroadcastHashJoin because table '${table1Name}' estimated size (${minTableSizeMB} MB) is within the 'spark.sql.autoBroadcastJoinThreshold' (${params.autoBroadcastJoinThreshold} MB).`
      : `Catalyst selected SortMergeJoin because both tables (${t1SizeMB} MB & ${t2SizeMB} MB) exceed the 'spark.sql.autoBroadcastJoinThreshold' (${params.autoBroadcastJoinThreshold} MB).`,
    whyItHappened: 'Physical planning converts logical relational operators into concrete algorithms that can run on distributed cluster executors.',
    underlyingMechanism: '`JoinSelection` strategy examines table size statistics. If a table fits in driver memory, it is broadcast via `TorrentBroadcast` to all executors, allowing local hash table lookups without redistributing the larger table.',
    consequences: isBroadcastSelected
      ? 'Zero network shuffle for the large table! Low latency, minimal disk spilling, and fast O(1) hash lookups.'
      : `Introduces 2 ShuffleExchange stages and full network partitioning across ${params.shufflePartitions} partitions, increasing I/O and latency.`,
    depths: {
      beginner: isBroadcastSelected
        ? 'Because the customer table is small, Spark sends a copy of it to every machine, so no big data shuffling over the network is needed!'
        : 'Because both tables are large, Spark must shuffle all data across machines by customer ID and sort it before merging.',
      technical: `JoinSelection strategy matched CanBroadcast. Selected ${joinType}. Added BroadcastExchangeExec with HashedRelation broadcast mode.`,
      internals: 'Strategy matches on `LogicalPlan` nodes and produces candidate `Seq[SparkPlan]`. CBO cost evaluation selected `BroadcastHashJoinExec` over `SortMergeJoinExec` based on table stats.',
    }
  };

  const shuffleBytes = isBroadcastSelected ? 0 : Math.round((t1SizeMB + t2SizeMB) * 0.85);
  const shuffleCount = isBroadcastSelected ? 0 : 2;

  snapshots.push({
    step: 4,
    mode,
    state: {
      ...step0State,
      phase: 'physical_planning',
      phaseIndex: 3,
      rootNode: step4Root,
      previousRootNode: step3Root,
      ruleApplications: [
        { ruleName: 'JoinSelection', timeMs: 15, affectedNode: joinType, description: `Selected ${joinType} based on threshold evaluation` },
        { ruleName: 'EnsureRequirements', timeMs: 9, affectedNode: isBroadcastSelected ? 'BroadcastExchange' : 'ShuffleExchange', description: 'Enforced distribution and partitioning invariants' }
      ],
      activeRule: {
        name: 'org.apache.spark.sql.execution.SparkStrategies.JoinSelection',
        description: 'Chooses physical join algorithm using data size statistics and hint directives.',
        scalaRule: 'JoinSelection',
        beforeSummary: 'Logical Join(Inner)',
        afterSummary: `Physical ${joinType}Exec`
      }
    },
    metrics: {
      planningTimeMs: 18.4,
      projectedMemoryMB: isBroadcastSelected ? Math.round(t1SizeMB * 1.5 + 40) : Math.round((t1SizeMB + t2SizeMB) * 0.4 + 180),
      shuffleVolumeMB: shuffleBytes,
      shuffleExchanges: shuffleCount,
      scannedRows: params.predicatePushdown ? Math.round(initialRowsTable1 * 0.2) + filteredRowsTable2 : initialRowsTable1 + initialRowsTable2,
      appliedRulesCount: 22,
      codegenLines: 0,
      estimatedLatencyMs: isBroadcastSelected ? 290 : 840,
    },
    activeLine: parsed.lineMap.joinLines[0] || parsed.lineMap.fromLine,
    event: step4Event,
    explanation: step4Explanation,
  });

  // STEP 5: WholeStageCodegen & RDD Stage DAG
  const javaCode = generateJaninoJavaCode({
    joinType,
    hasFilter: true,
    filterPushedToScan: params.predicatePushdown,
    columnsPruned: params.columnPruning,
    wholeStageEnabled: params.wholeStageCodegen,
    tableName1: table1Name,
    tableName2: table2Name,
  });

  const step5Root: PlanNode = {
    id: 'wholestage_wrapper',
    type: 'WholeStageCodegen',
    name: params.wholeStageCodegen ? 'WholeStageCodegen (1)' : 'VolcanoIterator (No Codegen)',
    title: params.wholeStageCodegen ? 'WholeStageCodegen [Stage 1 - Janino Compiled]' : 'Volcano Iterator Model (Codegen Disabled)',
    details: params.wholeStageCodegen
      ? 'Project Tungsten: Inlined pipeline compiled directly to Java bytecode'
      : 'Standard iterator next() calls per row across operators',
    isWholeStageCodegen: params.wholeStageCodegen,
    codegenStageId: 1,
    children: [step4Root]
  };

  const rddStages: RDDStage[] = isBroadcastSelected
    ? [
        {
          stageId: 0,
          name: `Stage 0: Broadcast [${table1Name}]`,
          operators: ['FileSourceScan', 'Filter', 'BroadcastExchange'],
          partitions: 4,
          parentStageIds: [],
          isShuffle: false,
          shuffleReadMB: 0,
          shuffleWriteMB: 0,
          status: 'completed',
        },
        {
          stageId: 1,
          name: `Stage 1: Pipelined Scan, Join & Project [${table2Name}]`,
          operators: ['FileSourceScan', 'Filter', 'BroadcastHashJoin', 'Project', 'WholeStageCodegen'],
          partitions: 16,
          parentStageIds: [0],
          isShuffle: false,
          shuffleReadMB: 0,
          shuffleWriteMB: 0,
          status: 'active',
        }
      ]
    : [
        {
          stageId: 0,
          name: `Stage 0: Shuffle Map [${table1Name}]`,
          operators: ['FileSourceScan', 'Filter', 'ShuffleExchange'],
          partitions: 8,
          parentStageIds: [],
          isShuffle: true,
          shuffleReadMB: 0,
          shuffleWriteMB: Math.round(t1SizeMB * 0.7),
          status: 'completed',
        },
        {
          stageId: 1,
          name: `Stage 1: Shuffle Map [${table2Name}]`,
          operators: ['FileSourceScan', 'Filter', 'ShuffleExchange'],
          partitions: 32,
          parentStageIds: [],
          isShuffle: true,
          shuffleReadMB: 0,
          shuffleWriteMB: Math.round(t2SizeMB * 0.6),
          status: 'completed',
        },
        {
          stageId: 2,
          name: `Stage 2: SortMergeJoin & Output`,
          operators: ['Sort', 'SortMergeJoin', 'Project'],
          partitions: params.shufflePartitions,
          parentStageIds: [0, 1],
          isShuffle: true,
          shuffleReadMB: Math.round((t1SizeMB + t2SizeMB) * 0.65),
          shuffleWriteMB: 0,
          status: 'active',
        }
      ];

  const step5Event: SimulationEvent = {
    id: 'evt_5',
    step: 5,
    timestamp: '00:00:01.240',
    type: 'CODEGEN',
    label: params.wholeStageCodegen ? 'Whole-Stage Code Generation Completed' : 'Volcano Execution Ready',
    description: params.wholeStageCodegen
      ? 'Project Tungsten compiled physical operator pipeline into a single high-performance Java class via Janino.'
      : 'WholeStageCodegen is disabled; Spark will execute via Volcano next() iterator model.',
    sourceLine: parsed.lineMap.selectLine,
    phase: 'WholeStageCodegen & Execution',
    impact: 'optimization',
  };

  const step5Explanation: StepExplanation = {
    step: 5,
    phase: 'Phase 5: Whole-Stage Code Generation & DAG Execution',
    title: params.wholeStageCodegen ? 'WholeStageCodegen Executed (Tungsten Engine)' : 'Volcano Iterator Pipeline Ready',
    whatHappened: params.wholeStageCodegen
      ? 'Catalyst collapsed the physical operator pipeline into a single Java class (`GeneratedIteratorForCodegenStage1`) and compiled it into JVM bytecode using the Janino in-memory compiler.'
      : 'Whole-stage code generation was disabled, causing Spark to evaluate operators row-by-row through traditional virtual method calls.',
    whyItHappened: 'In the Volcano iterator model, each row causes hundreds of virtual function dispatches (`child.next()`), stalling CPU instruction pipelines and causing frequent cache misses. Whole-Stage Codegen flattens everything into a tight while-loop that fits entirely in CPU registers.',
    underlyingMechanism: 'Physical operators implementing `CodegenSupport` generate fragments of Java code. `CollapseCodegenStages` groups adjacent supported operators into a `WholeStageCodegenExec` node, compiling the unified source via `CodeGenerator.compile()`.',
    consequences: params.wholeStageCodegen
      ? 'CPU efficiency increased by 3x-10x. Zero virtual dispatch overhead, cache-friendly off-heap UnsafeRow memory access.'
      : 'Execution will suffer from high JVM virtual dispatch overhead and poor CPU register utilization.',
    depths: {
      beginner: 'Spark synthesized custom Java code on the fly for your specific query, compiling it straight into machine bytecode for maximum speed.',
      technical: 'Operators merged under `WholeStageCodegenExec`. Synthesized code compiles via Janino and loads as `BufferedRowIterator`. UnsafeRowWriter buffers output off-heap.',
      internals: 'Generated source implements `produce()` and `consume()` patterns across `CodegenSupport` subclasses. Evaluated variables stored in Java local primitives to allow JIT register allocation.',
    }
  };

  const codegenLinesCount = params.wholeStageCodegen ? javaCode.split('\n').length : 0;

  snapshots.push({
    step: 5,
    mode,
    state: {
      ...step0State,
      phase: 'codegen_execution',
      phaseIndex: 4,
      rootNode: step5Root,
      previousRootNode: step4Root,
      stages: rddStages,
      generatedCode: javaCode,
      ruleApplications: [
        { ruleName: 'CollapseCodegenStages', timeMs: 12, affectedNode: 'WholeStageCodegen', description: 'Grouped physical operators into compiled stage' },
        { ruleName: 'JaninoCompilation', timeMs: 24, affectedNode: 'GeneratedIterator', description: 'Compiled Java source directly to JVM bytecode' }
      ],
      activeRule: {
        name: 'org.apache.spark.sql.execution.WholeStageCodegenExec',
        description: 'Tungsten Whole-Stage Java code generation and execution stage compilation.',
        scalaRule: 'CollapseCodegenStages',
        beforeSummary: 'Individual physical operator instances with virtual next() loops',
        afterSummary: 'Single compiled Java loop keeping data in CPU registers'
      }
    },
    metrics: {
      planningTimeMs: 26.2,
      projectedMemoryMB: isBroadcastSelected ? Math.round(t1SizeMB * 1.5 + 40) : Math.round((t1SizeMB + t2SizeMB) * 0.4 + 180),
      shuffleVolumeMB: shuffleBytes,
      shuffleExchanges: shuffleCount,
      scannedRows: params.predicatePushdown ? Math.round(initialRowsTable1 * 0.2) + filteredRowsTable2 : initialRowsTable1 + initialRowsTable2,
      appliedRulesCount: 28,
      codegenLines: codegenLinesCount,
      estimatedLatencyMs: isBroadcastSelected
        ? (params.wholeStageCodegen ? 190 : 380)
        : (params.wholeStageCodegen ? 680 : 1240),
    },
    activeLine: parsed.lineMap.selectLine,
    event: step5Event,
    explanation: step5Explanation,
  });

  return snapshots;
}

import { PlanAttribute } from '../../types/catalyst';

export interface CatalogTable {
  tableName: string;
  rowCount: number;
  sizeBytes: number;
  fileFormat: string;
  location: string;
  schema: PlanAttribute[];
}

export const SPARK_CATALOG: Record<string, CatalogTable> = {
  customers: {
    tableName: 'customers',
    rowCount: 250000,
    sizeBytes: 8 * 1024 * 1024, // 8 MB
    fileFormat: 'Parquet (Snappy)',
    location: 'hdfs://lakehouse/data/gold/customers',
    schema: [
      { name: 'customer_id', dataType: 'LongType', nullable: false },
      { name: 'customer_name', dataType: 'StringType', nullable: true },
      { name: 'tier', dataType: 'StringType', nullable: true },
      { name: 'country', dataType: 'StringType', nullable: true },
      { name: 'signup_date', dataType: 'DateType', nullable: true },
    ],
  },
  orders: {
    tableName: 'orders',
    rowCount: 12500000,
    sizeBytes: 450 * 1024 * 1024, // 450 MB
    fileFormat: 'Parquet (Snappy)',
    location: 'hdfs://lakehouse/data/gold/orders',
    schema: [
      { name: 'order_id', dataType: 'LongType', nullable: false },
      { name: 'customer_id', dataType: 'LongType', nullable: false },
      { name: 'product_id', dataType: 'LongType', nullable: false },
      { name: 'order_amount', dataType: 'DecimalType(10,2)', nullable: false },
      { name: 'order_date', dataType: 'DateType', nullable: false },
      { name: 'region', dataType: 'StringType', nullable: true },
      { name: 'status', dataType: 'StringType', nullable: false },
      { name: 'tax_rate', dataType: 'DoubleType', nullable: true },
      { name: 'quantity', dataType: 'IntegerType', nullable: true },
    ],
  },
  transactions: {
    tableName: 'transactions',
    rowCount: 20000000,
    sizeBytes: 850 * 1024 * 1024, // 850 MB
    fileFormat: 'Delta Lake',
    location: 's3a://fintech-lake/transactions',
    schema: [
      { name: 'transaction_id', dataType: 'StringType', nullable: false },
      { name: 'account_id', dataType: 'StringType', nullable: false },
      { name: 'amount', dataType: 'DecimalType(12,2)', nullable: false },
      { name: 'timestamp', dataType: 'TimestampType', nullable: false },
      { name: 'status', dataType: 'StringType', nullable: false },
    ],
  },
  accounts: {
    tableName: 'accounts',
    rowCount: 1500000,
    sizeBytes: 120 * 1024 * 1024, // 120 MB
    fileFormat: 'Delta Lake',
    location: 's3a://fintech-lake/accounts',
    schema: [
      { name: 'account_id', dataType: 'StringType', nullable: false },
      { name: 'account_type', dataType: 'StringType', nullable: false },
      { name: 'risk_score', dataType: 'IntegerType', nullable: true },
      { name: 'status', dataType: 'StringType', nullable: false },
      { name: 'balance', dataType: 'DecimalType(12,2)', nullable: false },
    ],
  },
  products: {
    tableName: 'products',
    rowCount: 80000,
    sizeBytes: 4 * 1024 * 1024, // 4 MB
    fileFormat: 'Parquet (Snappy)',
    location: 'hdfs://lakehouse/data/gold/products',
    schema: [
      { name: 'product_id', dataType: 'LongType', nullable: false },
      { name: 'product_name', dataType: 'StringType', nullable: false },
      { name: 'category', dataType: 'StringType', nullable: false },
      { name: 'price', dataType: 'DecimalType(8,2)', nullable: false },
      { name: 'stock', dataType: 'IntegerType', nullable: false },
    ],
  }
};

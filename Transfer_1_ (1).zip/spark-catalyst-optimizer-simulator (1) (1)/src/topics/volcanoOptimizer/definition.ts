import { SimulationTopic, SimulationSnapshot } from '../../types/simulation';

export interface VolcanoState {
  phase: 'Parsing' | 'LogicalTree' | 'CostEstimation' | 'PhysicalSelection' | 'Execution';
  selectedPlan: string;
  memoTable: Array<{ group: string; operator: string; cost: number; isWinner: boolean }>;
  activeOperation: string;
}

export const VOLCANO_OPTIMIZER_TOPIC: SimulationTopic<VolcanoState, string> = {
  id: 'volcano_optimizer',
  name: 'Volcano / System R Cost-Based Optimizer',
  shortName: 'Volcano CBO',
  category: 'Relational Database Internals',
  description: 'Explores dynamic programming memoization, cost search space exploration, index scan vs sequential scan, and nested loop vs hash join decisions in traditional RDBMS engines.',
  inputLanguage: 'sql',
  defaultCode: `SELECT e.name, d.department_name, e.salary
FROM employees e
JOIN departments d ON e.dept_id = d.id
WHERE e.salary > 75000 AND d.budget > 500000;`,
  presets: [
    {
      id: 'volcano_index_vs_seq',
      name: 'Index Scan vs Full Table Scan',
      description: 'Demonstrates when the optimizer flips from B-Tree index lookup to sequential scan based on selectivity.',
      code: `SELECT * FROM users WHERE age > 25 AND country = 'CA';`,
      parameters: { indexSelectivityPct: 15, tableTotalPages: 5000 }
    },
    {
      id: 'volcano_join_strategy',
      name: 'Hash Join vs Nested Loop',
      description: 'Compares nested loop join vs in-memory hash join based on buffer pool capacity.',
      code: `SELECT * FROM orders o JOIN lineitems l ON o.id = l.order_id;`,
      parameters: { bufferPoolMB: 64, joinMethod: 'HashJoin' }
    }
  ],
  parameters: [
    {
      id: 'indexSelectivityPct',
      label: 'Predicate Selectivity (%)',
      type: 'range',
      defaultValue: 15,
      min: 1,
      max: 100,
      step: 1,
      unit: '%',
      description: 'Percentage of table rows matching the query condition. Low selectivity favors index scan; high selectivity favors sequential scan.',
    },
    {
      id: 'bufferPoolMB',
      label: 'Database Buffer Pool',
      type: 'range',
      defaultValue: 64,
      min: 16,
      max: 512,
      step: 16,
      unit: 'MB',
      description: 'Dedicated RAM for shared table buffers and hash join work areas.',
    },
    {
      id: 'enableIndexScan',
      label: 'Enable Index Scans',
      type: 'boolean',
      defaultValue: true,
      description: 'Allow query optimizer to pick B-tree indexes if cost is lower.',
    }
  ],
  metrics: [
    { id: 'totalCost', label: 'Optimizer Total Cost', format: 'number', isKeyMetric: true },
    { id: 'ioReads', label: 'Disk Block I/O Reads', format: 'count', isKeyMetric: true },
    { id: 'memoryUsedMB', label: 'Buffer Cache Used', unit: 'MB', format: 'bytes' },
    { id: 'exploredPlans', label: 'Memo Search Space', format: 'count' },
  ],
  docs: {
    overview: 'The Volcano/Cascades framework (and System R) evaluates queries through goal-driven search and memoization. It explores candidate physical plans, computes cost models based on I/O and CPU, and picks the global minimum.',
    inputs: 'SQL relational query with tunable buffer cache, selectivity, and access method flags.',
    executionModel: 'Dynamic programming memo table partitions operators into equivalence groups, generating candidate implementations and pruning unviable sub-plans.',
    importantConcepts: ['Memo Equivalence Groups', 'B-Tree Index Clustering', 'Cost Function: I/O Cost + CPU Weight * Tuples'],
    performanceImplications: 'Incorrect statistics cause the optimizer to select catastrophic nested loop joins or random I/O index scans on large data fractions.',
    simulationNotes: 'Educational model demonstrating Volcano cost estimation and equivalence group memo expansion.'
  },
  parse: (input: string) => ({ ast: { text: input } }),
  validate: (input: string) => ({
    isValid: input.trim().length > 0,
    issues: input.trim().length > 0 ? [] : [{ message: 'Input cannot be empty', severity: 'error' }]
  }),
  buildExecutionPlan: (input: string, params: Record<string, any>) => {
    const selectivity = params.indexSelectivityPct ?? 15;
    const isIndexFavored = selectivity < 20 && (params.enableIndexScan ?? true);
    const chosenAccess = isIndexFavored ? 'IndexScan (B-Tree on dept_id)' : 'SeqScan (Heap scan)';
    const cost = isIndexFavored ? Math.round(selectivity * 28 + 120) : Math.round(520 + selectivity * 8);

    const steps: SimulationSnapshot<VolcanoState>[] = [
      {
        step: 0,
        mode: 'DEFAULT',
        state: {
          phase: 'Parsing',
          selectedPlan: 'Initial Relational Algebra Tree',
          memoTable: [],
          activeOperation: 'Parse SQL text into Relational Operators'
        },
        metrics: { totalCost: 0, ioReads: 0, memoryUsedMB: 4, exploredPlans: 1 },
        activeLine: 1,
        event: {
          id: 'v_0',
          step: 0,
          timestamp: '00:00:00.100',
          type: 'PARSE',
          label: 'Relational Expression Parsed',
          description: 'SQL statement parsed into relational operators (Project, Filter, Join, Scan).'
        },
        explanation: {
          step: 0,
          phase: 'Parsing & Normalization',
          title: 'Relational Expression Initialized',
          whatHappened: 'Created initial logical operator tree.',
          whyItHappened: 'Volcano requires an initial relational representation before applying equivalence transformations.',
          underlyingMechanism: 'Lexical parsing generates a logical operator tree: Project(Join(Scan, Scan)).',
          consequences: 'Plan is ready for memo table insertion.'
        }
      },
      {
        step: 1,
        mode: 'DEFAULT',
        state: {
          phase: 'LogicalTree',
          selectedPlan: 'Memo Group 0: Project, Group 1: Join, Group 2: Scan',
          memoTable: [
            { group: 'Group 0', operator: 'LogicalProject', cost: 10, isWinner: true },
            { group: 'Group 1', operator: 'LogicalJoin', cost: 340, isWinner: true },
            { group: 'Group 2', operator: 'LogicalScan(employees)', cost: 180, isWinner: true },
          ],
          activeOperation: 'Populate Memo Equivalence Groups'
        },
        metrics: { totalCost: 530, ioReads: 210, memoryUsedMB: 12, exploredPlans: 6 },
        activeLine: 2,
        event: {
          id: 'v_1',
          step: 1,
          timestamp: '00:00:00.220',
          type: 'MEMO_EXPANSION',
          label: 'Memo Table Populated',
          description: 'Constructed equivalence classes and registered rule transformations.'
        },
        explanation: {
          step: 1,
          phase: 'Search Space Expansion',
          title: 'Equivalence Groups Built',
          whatHappened: 'Sub-plans grouped into equivalence classes to prevent redundant re-computation.',
          whyItHappened: 'Without dynamic programming memoization, join order exploration produces exponential O(N!) complexity.',
          underlyingMechanism: 'Cascades memo structures organize equivalent logical plans into Groups with shared properties.',
          consequences: 'Enables top-down branch-and-bound cost pruning.'
        }
      },
      {
        step: 2,
        mode: 'DEFAULT',
        state: {
          phase: 'CostEstimation',
          selectedPlan: `Candidate Access Path Evaluation: ${chosenAccess}`,
          memoTable: [
            { group: 'Group 2', operator: 'SeqScan(employees)', cost: 580, isWinner: !isIndexFavored },
            { group: 'Group 2', operator: 'IndexScan(employees_dept_idx)', cost: Math.round(selectivity * 28 + 120), isWinner: isIndexFavored },
            { group: 'Group 1', operator: 'HashJoin', cost: 420, isWinner: true },
            { group: 'Group 1', operator: 'NestedLoopJoin', cost: 1850, isWinner: false },
          ],
          activeOperation: `Evaluate Cost Model for Access Methods (Selectivity: ${selectivity}%)`
        },
        metrics: { totalCost: cost, ioReads: isIndexFavored ? 140 : 580, memoryUsedMB: 32, exploredPlans: 14 },
        activeLine: 4,
        event: {
          id: 'v_2',
          step: 2,
          timestamp: '00:00:00.410',
          type: 'COST_EVAL',
          label: isIndexFavored ? 'Index Scan Selected by Cost Model' : 'Sequential Scan Selected (High Selectivity)',
          description: isIndexFavored
            ? `Selectivity (${selectivity}%) is low. Index scan cost (${cost}) beats sequential scan.`
            : `Selectivity (${selectivity}%) is high. Sequential scan chosen to avoid random disk seeks.`
        },
        explanation: {
          step: 2,
          phase: 'Physical Strategy Selection',
          title: `${chosenAccess} Chosen`,
          whatHappened: `Cost model evaluated access paths and selected ${chosenAccess}.`,
          whyItHappened: isIndexFavored
            ? 'Predicate matches a small percentage of rows; fetching index leaf pages plus clustered heap blocks is cheaper.'
            : 'At higher selectivities, random I/O seeks across index leaves degrade performance below contiguous sequential reads.',
          underlyingMechanism: 'Cost formula: Cost = (DiskPagesRead * 1.0) + (TuplesScanned * 0.01) + (RandomSeekPenalty * 4.0).',
          consequences: `Estimated physical execution cost locked in at ${cost} units.`
        }
      },
      {
        step: 3,
        mode: 'DEFAULT',
        state: {
          phase: 'Execution',
          selectedPlan: `Physical Plan: HashJoin -> ${chosenAccess}`,
          memoTable: [
            { group: 'Group 0', operator: 'PhysicalProject', cost: 10, isWinner: true },
            { group: 'Group 1', operator: 'HashJoin', cost: 280, isWinner: true },
            { group: 'Group 2', operator: chosenAccess, cost: cost, isWinner: true },
          ],
          activeOperation: 'Iterator Execution Pipeline Ready'
        },
        metrics: { totalCost: cost + 290, ioReads: isIndexFavored ? 160 : 610, memoryUsedMB: 48, exploredPlans: 14 },
        activeLine: 1,
        event: {
          id: 'v_3',
          step: 3,
          timestamp: '00:00:00.600',
          type: 'PLAN_FINALIZED',
          label: 'Physical Query Plan Finalized',
          description: 'Volcano query execution engine loaded physical iterator tree.'
        },
        explanation: {
          step: 3,
          phase: 'Execution Pipeline',
          title: 'Physical Plan Ready',
          whatHappened: 'Best plan selected from memo table and instantiated into physical operator iterator tree.',
          whyItHappened: 'The query optimization phase concluded with the lowest-cost physical execution tree.',
          underlyingMechanism: 'Engine initializes root operator iterator. Downstream open(), next(), and close() methods are invoked.',
          consequences: 'Query engine executes execution pipeline.'
        }
      }
    ];

    return { steps, totalSteps: steps.length };
  }
};

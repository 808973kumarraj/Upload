import React from 'react';
import { TopicDocs } from '../types/simulation';
import { X, BookOpen, CheckCircle, Info, Cpu, Sparkles } from 'lucide-react';

interface TopicDocsModalProps {
  isOpen: boolean;
  onClose: () => void;
  topicName: string;
  docs: TopicDocs;
}

export function TopicDocsModal({
  isOpen,
  onClose,
  topicName,
  docs,
}: TopicDocsModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl max-w-3xl w-full max-h-[85vh] flex flex-col overflow-hidden text-slate-200">
        {/* Header */}
        <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-cyan-400" />
            <span className="font-bold text-sm">Catalyst Architectural Guide: {topicName}</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-slate-800 text-slate-400 hover:text-slate-200 rounded transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-auto p-4 space-y-4 text-xs leading-relaxed">
          {/* Section 1: Overview */}
          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="font-semibold text-cyan-300 font-mono text-[11px] uppercase block mb-1">
              1. System Overview
            </span>
            <p className="text-slate-300">{docs.overview}</p>
          </div>

          {/* Section 2: Four Core Catalyst Phases */}
          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2">
            <span className="font-semibold text-indigo-300 font-mono text-[11px] uppercase block">
              2. The 4 Catalyst Optimization Phases
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
              <div className="p-2 rounded bg-slate-900 border border-slate-800">
                <strong className="text-cyan-300 block mb-0.5">Phase 1: Analysis</strong>
                <p className="text-slate-400">
                  Resolves <code className="text-slate-300">UnresolvedRelation</code> and <code className="text-slate-300">UnresolvedAttribute</code> nodes using the Spark SessionCatalog, attaching verifiable types and unique Expression IDs.
                </p>
              </div>

              <div className="p-2 rounded bg-slate-900 border border-slate-800">
                <strong className="text-emerald-300 block mb-0.5">Phase 2: Logical Optimization</strong>
                <p className="text-slate-400">
                  Executes rule batches (RBO) via fixed-point iterations. Pushes filter predicates to scans, prunes unused columns, folds static constant math, and propagates nulls.
                </p>
              </div>

              <div className="p-2 rounded bg-slate-900 border border-slate-800">
                <strong className="text-purple-300 block mb-0.5">Phase 3: Physical Planning</strong>
                <p className="text-slate-400">
                  Transforms logical relations into executable <code className="text-slate-300">SparkPlan</code> operators. Evaluates join strategies (BroadcastHashJoin vs SortMergeJoin) and inserts Shuffle Exchanges.
                </p>
              </div>

              <div className="p-2 rounded bg-slate-900 border border-slate-800">
                <strong className="text-amber-300 block mb-0.5">Phase 4: Whole-Stage Codegen</strong>
                <p className="text-slate-400">
                  Project Tungsten synthesizes unified Java classes and compiles them in-memory using Janino, eliminating virtual method invocations and pipelining rows in CPU registers.
                </p>
              </div>
            </div>
          </div>

          {/* Section 3: Important Concepts */}
          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="font-semibold text-cyan-300 font-mono text-[11px] uppercase block mb-1.5">
              3. Key Engineering Concepts
            </span>
            <ul className="space-y-1.5">
              {docs.importantConcepts.map((c, i) => (
                <li key={i} className="flex items-start gap-1.5 text-slate-300">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0 mt-0.5" />
                  <span>{c}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Section 4: Performance Implications */}
          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="font-semibold text-emerald-400 font-mono text-[11px] uppercase block mb-1">
              4. Performance Tuning & Best Practices
            </span>
            <p className="text-slate-300">{docs.performanceImplications}</p>
          </div>

          {/* Section 5: Simulation Notes */}
          <div className="bg-indigo-950/30 border border-indigo-800/60 p-3 rounded text-[11px] text-indigo-300">
            <strong className="block mb-0.5 font-mono text-indigo-200">Simulation Fidelity Notice:</strong>
            {docs.simulationNotes}
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-950 px-4 py-2.5 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-3 py-1 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded text-xs transition-colors"
          >
            Got It
          </button>
        </div>
      </div>
    </div>
  );
}

import React from 'react';
import { SimulationTopic } from '../types/simulation';
import { CatalystVisualizer } from './CatalystVisualizer';
import { VolcanoVisualizer } from './VolcanoVisualizer';

interface VisualizerRouterProps {
  topic: SimulationTopic;
  state: any;
}

export function VisualizerRouter({ topic, state }: VisualizerRouterProps) {
  if (topic.id === 'spark_catalyst') {
    return <CatalystVisualizer state={state} />;
  }

  if (topic.id === 'volcano_optimizer') {
    return <VolcanoVisualizer state={state} />;
  }

  return (
    <div className="bg-slate-900 border border-slate-800 rounded p-6 text-center text-slate-400">
      Visualizer not registered for topic: {topic.name}
    </div>
  );
}

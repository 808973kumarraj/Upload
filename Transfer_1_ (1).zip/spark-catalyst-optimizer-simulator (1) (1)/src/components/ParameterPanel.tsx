import React from 'react';
import { ParameterDefinition } from '../types/simulation';
import { Sliders, HelpCircle, RefreshCw } from 'lucide-react';

interface ParameterPanelProps {
  parameters: ParameterDefinition[];
  values: Record<string, any>;
  onChange: (id: string, value: any) => void;
  onResetParams: () => void;
}

export function ParameterPanel({
  parameters,
  values,
  onChange,
  onResetParams,
}: ParameterPanelProps) {
  // Group by category if defined
  const categories = Array.from(new Set(parameters.map((p) => p.category || 'General')));

  return (
    <div id="parameters-panel" className="bg-slate-900 border border-slate-800 rounded-lg p-3 text-slate-200">
      <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800 text-xs">
        <div className="flex items-center gap-1.5 font-semibold text-slate-300">
          <Sliders className="w-3.5 h-3.5 text-cyan-400" />
          <span>Simulation Tuning Parameters</span>
        </div>
        <button
          onClick={onResetParams}
          className="text-slate-400 hover:text-slate-200 text-[11px] flex items-center gap-1 hover:underline"
          title="Restore default parameters"
        >
          <RefreshCw className="w-3 h-3" />
          <span>Defaults</span>
        </button>
      </div>

      <div className="space-y-4 text-xs">
        {categories.map((cat) => {
          const catParams = parameters.filter((p) => (p.category || 'General') === cat);
          return (
            <div key={cat} className="space-y-2.5">
              <div className="text-[10px] font-mono uppercase tracking-wider text-slate-500 font-semibold">
                {cat}
              </div>

              {catParams.map((param) => {
                const curVal = values[param.id] ?? param.defaultValue;

                return (
                  <div key={param.id} className="bg-slate-950/60 p-2 rounded border border-slate-800/80">
                    <div className="flex items-center justify-between mb-1.5">
                      <label htmlFor={`param-${param.id}`} className="font-medium text-slate-300 flex items-center gap-1 cursor-pointer">
                        <span>{param.label}</span>
                        {param.description && (
                          <span title={param.description}>
                            <HelpCircle className="w-3 h-3 text-slate-500 hover:text-slate-300" />
                          </span>
                        )}
                      </label>

                      {/* Display current value badge */}
                      <span className="font-mono text-[11px] px-1.5 py-0.5 rounded bg-slate-800 text-cyan-300 border border-slate-700">
                        {typeof curVal === 'boolean'
                          ? curVal ? 'ENABLED' : 'DISABLED'
                          : `${curVal}${param.unit ? ` ${param.unit}` : ''}`}
                      </span>
                    </div>

                    {/* Range / Slider */}
                    {param.type === 'range' && (
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] text-slate-500 font-mono">{param.min}</span>
                        <input
                          id={`param-${param.id}`}
                          type="range"
                          min={param.min}
                          max={param.max}
                          step={param.step || 1}
                          value={curVal}
                          onChange={(e) => onChange(param.id, Number(e.target.value))}
                          className="flex-1 accent-cyan-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                        />
                        <span className="text-[10px] text-slate-500 font-mono">{param.max}</span>
                      </div>
                    )}

                    {/* Boolean Toggle */}
                    {param.type === 'boolean' && (
                      <div className="flex items-center gap-2 mt-1">
                        <button
                          type="button"
                          id={`param-${param.id}`}
                          onClick={() => onChange(param.id, !curVal)}
                          className={`relative inline-flex h-5 w-9 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                            curVal ? 'bg-cyan-600' : 'bg-slate-800'
                          }`}
                        >
                          <span
                            className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                              curVal ? 'translate-x-4' : 'translate-x-0'
                            }`}
                          />
                        </button>
                        <span className="text-[11px] text-slate-400">
                          {curVal ? 'Active in Catalyst planner' : 'Bypassed in planner'}
                        </span>
                      </div>
                    )}

                    {/* Select Dropdown */}
                    {param.type === 'select' && param.options && (
                      <select
                        id={`param-${param.id}`}
                        value={curVal}
                        onChange={(e) => {
                          const val = isNaN(Number(e.target.value)) ? e.target.value : Number(e.target.value);
                          onChange(param.id, val);
                        }}
                        className="w-full mt-1 bg-slate-900 border border-slate-700 text-slate-200 rounded px-2 py-1 text-xs outline-none focus:border-cyan-500"
                      >
                        {param.options.map((opt) => (
                          <option key={String(opt.value)} value={String(opt.value)}>
                            {opt.label}
                          </option>
                        ))}
                      </select>
                    )}
                  </div>
                );
              })}
            </div>
          );
        })}
      </div>
    </div>
  );
}

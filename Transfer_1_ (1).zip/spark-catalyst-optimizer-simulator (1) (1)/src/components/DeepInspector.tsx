import React from 'react';
import { StepExplanation, ExplanationDepth } from '../types/simulation';
import {
  FileSearch,
  HelpCircle,
  Cpu,
  TrendingUp,
  Layers,
  Sparkles,
  BookOpen
} from 'lucide-react';

interface DeepInspectorProps {
  explanation?: StepExplanation;
  depth: ExplanationDepth;
  onChangeDepth: (depth: ExplanationDepth) => void;
}

export function DeepInspector({
  explanation,
  depth,
  onChangeDepth,
}: DeepInspectorProps) {
  if (!explanation) {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 text-center text-slate-500 text-xs">
        Select or advance a step to inspect technical details.
      </div>
    );
  }

  // Get progressive explanation according to depth
  const depthText =
    depth === 'beginner'
      ? explanation.depths?.beginner || explanation.whatHappened
      : depth === 'technical'
      ? explanation.depths?.technical || explanation.whyItHappened
      : explanation.depths?.internals || explanation.underlyingMechanism;

  return (
    <div id="deep-inspector" className="bg-slate-900 border border-slate-800 rounded-lg p-3 text-slate-200">
      {/* Header with Depth Selector */}
      <div className="flex flex-wrap items-center justify-between pb-2 mb-3 border-b border-slate-800 gap-2 text-xs">
        <div className="flex items-center gap-2">
          <FileSearch className="w-4 h-4 text-cyan-400" />
          <span className="font-bold text-slate-200">{explanation.title}</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded bg-indigo-950 border border-indigo-800 text-indigo-300 font-mono">
            {explanation.phase}
          </span>
        </div>

        {/* Depth Selector: Beginner / Technical / Internals */}
        <div className="flex items-center bg-slate-950 p-0.5 rounded border border-slate-800 text-[11px]">
          <button
            id="depth-beginner"
            onClick={() => onChangeDepth('beginner')}
            className={`px-2 py-0.5 rounded transition-colors ${
              depth === 'beginner'
                ? 'bg-slate-800 text-cyan-300 font-medium'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Beginner
          </button>
          <button
            id="depth-technical"
            onClick={() => onChangeDepth('technical')}
            className={`px-2 py-0.5 rounded transition-colors ${
              depth === 'technical'
                ? 'bg-slate-800 text-cyan-300 font-medium'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Technical
          </button>
          <button
            id="depth-internals"
            onClick={() => onChangeDepth('internals')}
            className={`px-2 py-0.5 rounded transition-colors ${
              depth === 'internals'
                ? 'bg-slate-800 text-cyan-300 font-medium'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Internals
          </button>
        </div>
      </div>

      {/* Dynamic Explanation Summary Callout */}
      <div className="bg-slate-950/80 border border-slate-800/80 p-2.5 rounded mb-3 text-xs leading-relaxed text-slate-300">
        <span className="text-[10px] font-mono uppercase tracking-wider text-cyan-400 font-semibold block mb-1">
          {depth.toUpperCase()} PERSPECTIVE
        </span>
        <p>{depthText}</p>
      </div>

      {/* 4 Standard Required Sections (#28) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
        {/* Section 1: What Happened? */}
        <div className="bg-slate-950/60 p-2.5 rounded border border-slate-800/80">
          <div className="flex items-center gap-1.5 font-semibold text-slate-300 mb-1">
            <HelpCircle className="w-3.5 h-3.5 text-blue-400" />
            <span>1. What Happened?</span>
          </div>
          <p className="text-slate-400 text-[11px] leading-relaxed">
            {explanation.whatHappened}
          </p>
        </div>

        {/* Section 2: Why It Happened? */}
        <div className="bg-slate-950/60 p-2.5 rounded border border-slate-800/80">
          <div className="flex items-center gap-1.5 font-semibold text-slate-300 mb-1">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>2. Why It Happened?</span>
          </div>
          <p className="text-slate-400 text-[11px] leading-relaxed">
            {explanation.whyItHappened}
          </p>
        </div>

        {/* Section 3: Underlying Mechanism */}
        <div className="bg-slate-950/60 p-2.5 rounded border border-slate-800/80">
          <div className="flex items-center gap-1.5 font-semibold text-slate-300 mb-1">
            <Cpu className="w-3.5 h-3.5 text-purple-400" />
            <span>3. Underlying Mechanism</span>
          </div>
          <p className="text-slate-400 text-[11px] leading-relaxed font-mono">
            {explanation.underlyingMechanism}
          </p>
        </div>

        {/* Section 4: Performance / Behavioral Consequences */}
        <div className="bg-slate-950/60 p-2.5 rounded border border-slate-800/80">
          <div className="flex items-center gap-1.5 font-semibold text-slate-300 mb-1">
            <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
            <span>4. Performance & Consequences</span>
          </div>
          <p className="text-slate-400 text-[11px] leading-relaxed">
            {explanation.consequences}
          </p>
        </div>
      </div>
    </div>
  );
}

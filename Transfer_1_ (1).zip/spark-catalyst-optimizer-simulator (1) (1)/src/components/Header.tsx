import { useState } from 'react';
import {
  Layers,
  Code,
  Eye,
  BookOpen,
  GitCompare,
  Terminal,
  ChevronDown,
  Info,
  CheckCircle2,
  Cpu,
  Flame
} from 'lucide-react';
import { SimulationTopic, ExecutionMode, SimulationStatus, ScenarioPreset } from '../types/simulation';

export type WorkbenchView = 'split' | 'benchmark' | 'edit';

interface HeaderProps {
  topics: SimulationTopic[];
  activeTopic: SimulationTopic;
  onSelectTopic: (topicId: string) => void;
  activePreset?: ScenarioPreset;
  onSelectPreset: (preset: ScenarioPreset) => void;
  mode: ExecutionMode;
  status: SimulationStatus;
  currentStep: number;
  totalSteps: number;
  activeView: WorkbenchView;
  onChangeView: (view: WorkbenchView) => void;
  onOpenDocs: () => void;
  onOpenComparison: () => void;
}

export function Header({
  topics,
  activeTopic,
  onSelectTopic,
  activePreset,
  onSelectPreset,
  mode,
  status,
  currentStep,
  totalSteps,
  activeView,
  onChangeView,
  onOpenDocs,
  onOpenComparison,
}: HeaderProps) {
  const [topicDropdownOpen, setTopicDropdownOpen] = useState(false);
  const [presetDropdownOpen, setPresetDropdownOpen] = useState(false);

  const getStatusBadge = () => {
    if (status === 'error') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold bg-rose-950/80 text-rose-300 border border-rose-800">
          <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse" />
          ERROR
        </span>
      );
    }
    if (status === 'running') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold bg-cyan-950/80 text-cyan-300 border border-cyan-800">
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
          RUNNING
        </span>
      );
    }
    if (status === 'completed' || currentStep >= totalSteps - 1) {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold bg-emerald-950/80 text-emerald-300 border border-emerald-800">
          <CheckCircle2 className="w-3 h-3 text-emerald-400" />
          COMPLETED
        </span>
      );
    }
    if (mode === 'CUSTOM') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold bg-amber-950/80 text-amber-300 border border-amber-800">
          <Flame className="w-3 h-3 text-amber-400" />
          CUSTOM EXECUTING
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold bg-slate-800 text-slate-300 border border-slate-700">
        <span className="w-1.5 h-1.5 rounded-full bg-blue-400" />
        DEFAULT BENCHMARK
      </span>
    );
  };

  return (
    <header id="workstation-header" className="bg-slate-950 border-b border-slate-800 px-4 py-2 flex flex-wrap items-center justify-between gap-3 text-slate-200">
      {/* Topic selection & brand */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded bg-gradient-to-tr from-cyan-600 to-indigo-600 flex items-center justify-center shadow-inner">
            <Cpu className="w-4 h-4 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold tracking-tight text-white text-sm sm:text-base">
                Spark Catalyst Workstation
              </span>
              <span className="text-[10px] font-mono px-1.5 py-0.2 bg-indigo-950 border border-indigo-800 text-indigo-300 rounded">
                SIMULATOR
              </span>
            </div>
            <div className="text-[11px] text-slate-400 flex items-center gap-1">
              <span>Topic Engine:</span>
              {/* Topic dropdown */}
              <div className="relative inline-block">
                <button
                  id="btn-topic-selector"
                  onClick={() => setTopicDropdownOpen(!topicDropdownOpen)}
                  className="font-medium text-cyan-300 hover:text-cyan-200 underline decoration-dotted flex items-center gap-0.5"
                >
                  <span>{activeTopic.shortName}</span>
                  <ChevronDown className="w-3 h-3" />
                </button>

                {topicDropdownOpen && (
                  <div className="absolute left-0 mt-1 w-72 bg-slate-900 border border-slate-700 rounded shadow-xl py-1 z-50">
                    <div className="px-3 py-1 text-[10px] uppercase tracking-wider text-slate-400 font-mono border-b border-slate-800">
                      Simulation Topics
                    </div>
                    {topics.map((t) => (
                      <button
                        key={t.id}
                        id={`topic-option-${t.id}`}
                        onClick={() => {
                          onSelectTopic(t.id);
                          setTopicDropdownOpen(false);
                        }}
                        className={`w-full text-left px-3 py-2 text-xs hover:bg-slate-800 flex flex-col ${
                          t.id === activeTopic.id ? 'bg-slate-800/80 text-cyan-300 font-semibold' : 'text-slate-300'
                        }`}
                      >
                        <span className="font-medium">{t.name}</span>
                        <span className="text-[10px] text-slate-400">{t.category}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Preset scenario dropdown */}
        {activeTopic.presets && activeTopic.presets.length > 0 && (
          <div className="relative hidden md:block">
            <button
              id="btn-preset-selector"
              onClick={() => setPresetDropdownOpen(!presetDropdownOpen)}
              className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded text-xs text-slate-300 flex items-center gap-1.5 transition-colors"
            >
              <Terminal className="w-3.5 h-3.5 text-amber-400" />
              <span className="max-w-[160px] truncate">{activePreset?.name || 'Scenarios'}</span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>

            {presetDropdownOpen && (
              <div className="absolute left-0 mt-1 w-80 bg-slate-900 border border-slate-700 rounded shadow-xl py-1 z-50">
                <div className="px-3 py-1 text-[10px] uppercase tracking-wider text-slate-400 font-mono border-b border-slate-800">
                  Scenario Presets
                </div>
                {activeTopic.presets.map((preset) => (
                  <button
                    key={preset.id}
                    id={`preset-option-${preset.id}`}
                    onClick={() => {
                      onSelectPreset(preset);
                      setPresetDropdownOpen(false);
                    }}
                    className={`w-full text-left px-3 py-2 text-xs hover:bg-slate-800 flex flex-col ${
                      preset.id === activePreset?.id ? 'bg-slate-800/80 text-amber-300 font-medium' : 'text-slate-300'
                    }`}
                  >
                    <span className="font-medium">{preset.name}</span>
                    <span className="text-[11px] text-slate-400 mt-0.5 line-clamp-2">{preset.description}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Execution status & step counter */}
      <div className="flex items-center gap-2.5">
        {getStatusBadge()}

        <div className="bg-slate-900 border border-slate-800 px-2.5 py-1 rounded font-mono text-xs flex items-center gap-1 text-slate-300">
          <span className="text-slate-500">STEP</span>
          <span className="font-bold text-cyan-400">{String(currentStep + 1).padStart(2, '0')}</span>
          <span className="text-slate-600">/</span>
          <span className="text-slate-400">{String(totalSteps).padStart(2, '0')}</span>
        </div>
      </div>

      {/* View Switcher & Action Modals */}
      <div className="flex items-center gap-2">
        {/* View Switcher: Split / Benchmark / Edit */}
        <div className="hidden sm:flex bg-slate-900 p-0.5 rounded border border-slate-800 text-xs">
          <button
            id="view-split"
            onClick={() => onChangeView('split')}
            className={`px-2.5 py-1 rounded flex items-center gap-1 transition-colors ${
              activeView === 'split' ? 'bg-slate-800 text-white font-medium shadow' : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Split View: Default Benchmark & Edit Space side-by-side"
          >
            <Layers className="w-3.5 h-3.5 text-cyan-400" />
            <span>Split View</span>
          </button>
          <button
            id="view-benchmark"
            onClick={() => onChangeView('benchmark')}
            className={`px-2.5 py-1 rounded flex items-center gap-1 transition-colors ${
              activeView === 'benchmark' ? 'bg-slate-800 text-white font-medium shadow' : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Benchmark Focus: Full width read-only canonical query"
          >
            <Eye className="w-3.5 h-3.5 text-blue-400" />
            <span>Benchmark</span>
          </button>
          <button
            id="view-edit"
            onClick={() => onChangeView('edit')}
            className={`px-2.5 py-1 rounded flex items-center gap-1 transition-colors ${
              activeView === 'edit' ? 'bg-slate-800 text-white font-medium shadow' : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Edit Focus: Full width interactive editor"
          >
            <Code className="w-3.5 h-3.5 text-amber-400" />
            <span>Edit Space</span>
          </button>
        </div>

        {/* Compare Runs Button */}
        <button
          id="btn-open-comparison"
          onClick={onOpenComparison}
          className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white rounded text-xs flex items-center gap-1 transition-colors"
          title="Compare Default vs Custom Execution Plans & Telemetry"
        >
          <GitCompare className="w-3.5 h-3.5 text-indigo-400" />
          <span className="hidden md:inline">Compare</span>
        </button>

        {/* Documentation / Architecture Modal */}
        <button
          id="btn-open-docs"
          onClick={onOpenDocs}
          className="px-2.5 py-1 bg-indigo-950/60 hover:bg-indigo-900/80 border border-indigo-700 text-indigo-200 rounded text-xs flex items-center gap-1 transition-colors"
          title="Catalyst Architecture & Workstation Guide"
        >
          <BookOpen className="w-3.5 h-3.5 text-indigo-300" />
          <span className="hidden md:inline">Guide</span>
        </button>
      </div>
    </header>
  );
}

import { useState, useEffect } from 'react';
import {
  Copy,
  ArrowRight,
  PlayCircle,
  AlertCircle,
  Check,
  FileCode,
  Sparkles,
  Lock,
  Edit3
} from 'lucide-react';
import { ValidationResult } from '../types/simulation';
import { WorkbenchView } from './Header';

interface WorkbenchProps {
  benchmarkCode: string;
  editCode: string;
  onChangeEditCode: (newCode: string) => void;
  activeLine?: number;
  view: WorkbenchView;
  validationResult?: ValidationResult;
  onExecuteCustom: () => void;
  onCopyToEditSpace: () => void;
  isExecuting?: boolean;
}

export function Workbench({
  benchmarkCode,
  editCode,
  onChangeEditCode,
  activeLine,
  view,
  validationResult,
  onExecuteCustom,
  onCopyToEditSpace,
  isExecuting,
}: WorkbenchProps) {
  const [copiedBenchmark, setCopiedBenchmark] = useState(false);

  const benchmarkLines = benchmarkCode.split('\n');
  const editLines = editCode.split('\n');

  const handleCopyBenchmark = () => {
    navigator.clipboard.writeText(benchmarkCode);
    setCopiedBenchmark(true);
    setTimeout(() => setCopiedBenchmark(false), 2000);
  };

  const hasErrors = validationResult && !validationResult.isValid;

  // Keyboard shortcut Ctrl+Enter or Cmd+Enter to execute custom query
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        e.preventDefault();
        onExecuteCustom();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onExecuteCustom]);

  return (
    <div id="workbench-container" className="bg-slate-950 border-b border-slate-800">
      <div className={`grid ${view === 'split' ? 'grid-cols-1 lg:grid-cols-2' : 'grid-cols-1'} divide-y lg:divide-y-0 lg:divide-x divide-slate-800`}>
        {/* PANEL A: DEFAULT BENCHMARK (Read-only) */}
        {(view === 'split' || view === 'benchmark') && (
          <div id="panel-default-benchmark" className="flex flex-col h-[280px] bg-slate-950">
            {/* Benchmark Toolbar */}
            <div className="bg-slate-900/90 px-3 py-1.5 border-b border-slate-800 flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5 text-slate-300 font-mono">
                <Lock className="w-3.5 h-3.5 text-slate-500" />
                <span className="font-semibold text-slate-200">Default Benchmark</span>
                <span className="text-[10px] px-1 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">READ-ONLY</span>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  id="btn-copy-to-edit"
                  onClick={onCopyToEditSpace}
                  className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-cyan-300 hover:text-cyan-200 border border-slate-700 rounded text-[11px] flex items-center gap-1 transition-colors"
                  title="Copy benchmark query into the editable space"
                >
                  <ArrowRight className="w-3 h-3 text-cyan-400" />
                  <span>Copy to Edit Space</span>
                </button>

                <button
                  id="btn-copy-benchmark-raw"
                  onClick={handleCopyBenchmark}
                  className="p-1 hover:bg-slate-800 text-slate-400 hover:text-slate-200 rounded transition-colors"
                  title="Copy to clipboard"
                >
                  {copiedBenchmark ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            {/* Benchmark Code View with active instruction cursor */}
            <div className="flex-1 overflow-auto p-2 font-mono text-xs text-slate-300 leading-relaxed select-text">
              <table className="w-full border-collapse">
                <tbody>
                  {benchmarkLines.map((line, idx) => {
                    const lineNum = idx + 1;
                    const isActive = activeLine === lineNum;
                    const isComment = line.trim().startsWith('--');

                    return (
                      <tr
                        key={idx}
                        className={`transition-colors ${
                          isActive
                            ? 'bg-cyan-950/60 border-l-2 border-cyan-400 text-cyan-100 font-semibold'
                            : 'hover:bg-slate-900/40'
                        }`}
                      >
                        <td className="w-8 text-right pr-3 select-none text-slate-600 text-[11px] font-mono align-top py-0.5">
                          {lineNum}
                        </td>
                        <td className="py-0.5 whitespace-pre font-mono">
                          {isActive && (
                            <span className="inline-block w-2 h-2 rounded-full bg-cyan-400 mr-1.5 animate-pulse" />
                          )}
                          <span className={isComment ? 'text-slate-500 italic' : highlightSqlKeywords(line)}>
                            {line}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* PANEL B: INTERACTIVE EDIT SPACE (Editable) */}
        {(view === 'split' || view === 'edit') && (
          <div id="panel-interactive-edit" className="flex flex-col h-[280px] bg-slate-950">
            {/* Edit Space Toolbar */}
            <div className="bg-slate-900/90 px-3 py-1.5 border-b border-slate-800 flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5 text-slate-300 font-mono">
                <Edit3 className="w-3.5 h-3.5 text-amber-400" />
                <span className="font-semibold text-slate-200">Interactive Edit Space</span>
                <span className="text-[10px] px-1 py-0.5 rounded bg-amber-950/80 text-amber-300 border border-amber-800">CUSTOM</span>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-[11px] text-slate-500 hidden sm:inline font-mono">
                  Ctrl+Enter to Run
                </span>
                <button
                  id="btn-execute-manually"
                  onClick={onExecuteCustom}
                  disabled={isExecuting}
                  className="px-3 py-1 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 active:scale-95 text-slate-950 font-bold rounded text-xs flex items-center gap-1.5 transition-all shadow-md"
                  title="Parse and execute modified query deterministically"
                >
                  <PlayCircle className="w-3.5 h-3.5" />
                  <span>Execute Manually</span>
                </button>
              </div>
            </div>

            {/* Inline validation issues if any */}
            {hasErrors && validationResult?.issues && (
              <div className="bg-rose-950/70 border-b border-rose-800/80 px-3 py-1 text-xs text-rose-300 flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5 flex-shrink-0 text-rose-400" />
                <span className="truncate">
                  {validationResult.issues[0].message}
                </span>
              </div>
            )}

            {/* Code Textarea with line numbers */}
            <div className="flex-1 relative flex overflow-hidden">
              {/* Line numbers gutter */}
              <div className="w-9 bg-slate-900/60 border-r border-slate-800/60 p-2 text-right select-none font-mono text-[11px] text-slate-600 leading-relaxed">
                {editLines.map((_, i) => (
                  <div key={i}>{i + 1}</div>
                ))}
              </div>

              {/* Textarea */}
              <textarea
                id="interactive-code-editor"
                value={editCode}
                onChange={(e) => onChangeEditCode(e.target.value)}
                spellCheck={false}
                className="flex-1 p-2 bg-transparent font-mono text-xs text-slate-200 resize-none outline-none leading-relaxed overflow-auto selection:bg-cyan-900"
                placeholder="Enter custom SQL or Spark query definition here..."
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// Simple syntax-aware class assigner for readable queries
function highlightSqlKeywords(line: string): string {
  const trimmed = line.trim().toUpperCase();
  if (trimmed.startsWith('SELECT') || trimmed.startsWith('FROM') || trimmed.startsWith('WHERE') || trimmed.startsWith('JOIN') || trimmed.startsWith('ORDER BY') || trimmed.startsWith('GROUP BY')) {
    return 'text-cyan-300 font-medium';
  }
  if (line.includes('AND ') || line.includes('OR ') || line.includes('ON ')) {
    return 'text-indigo-300';
  }
  return 'text-slate-200';
}

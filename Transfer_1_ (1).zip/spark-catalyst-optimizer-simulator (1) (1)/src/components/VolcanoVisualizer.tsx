import React from 'react';
import { VolcanoState } from '../topics/volcanoOptimizer/definition';
import { Database, Search, Cpu, CheckCircle } from 'lucide-react';

interface VolcanoVisualizerProps {
  state: VolcanoState;
}

export function VolcanoVisualizer({ state }: VolcanoVisualizerProps) {
  return (
    <div id="volcano-visualizer" className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col h-[520px] overflow-hidden text-xs">
      <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
        <div className="flex items-center gap-2">
          <Database className="w-4 h-4 text-cyan-400" />
          <span className="font-bold text-slate-200 text-sm">Volcano / Cascades Dynamic Programming Memo</span>
        </div>
        <span className="px-2 py-0.5 rounded bg-indigo-950 border border-indigo-800 text-indigo-300 font-mono">
          Phase: {state.phase}
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 flex-1 overflow-hidden">
        {/* Memo Equivalence Groups */}
        <div className="bg-slate-950 border border-slate-800 rounded p-3 flex flex-col">
          <div className="font-semibold text-slate-300 mb-2 flex items-center gap-1.5">
            <Search className="w-3.5 h-3.5 text-cyan-400" />
            <span>Memo Equivalence Groups & Candidates</span>
          </div>

          <div className="flex-1 overflow-auto space-y-2">
            {state.memoTable.length === 0 ? (
              <div className="text-slate-500 py-8 text-center">Memo space being populated during initialization...</div>
            ) : (
              state.memoTable.map((item, idx) => (
                <div
                  key={idx}
                  className={`p-2 rounded border font-mono flex items-center justify-between ${
                    item.isWinner
                      ? 'bg-emerald-950/30 border-emerald-800 text-emerald-200'
                      : 'bg-slate-900 border-slate-800 text-slate-400 opacity-60'
                  }`}
                >
                  <div>
                    <span className="text-[10px] text-slate-500 mr-2">{item.group}</span>
                    <span className="font-medium">{item.operator}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px]">Cost: {item.cost}</span>
                    {item.isWinner && <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Plan Evaluation Status */}
        <div className="bg-slate-950 border border-slate-800 rounded p-3 flex flex-col justify-between">
          <div>
            <div className="font-semibold text-slate-300 mb-2 flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-indigo-400" />
              <span>Active Cost-Based Plan Selection</span>
            </div>

            <div className="p-3 bg-slate-900 rounded border border-slate-800 font-mono text-cyan-300 mb-3">
              {state.selectedPlan}
            </div>

            <div className="space-y-2 text-slate-400">
              <div className="text-[11px]">
                <strong className="text-slate-300">Active Operation:</strong> {state.activeOperation}
              </div>
              <p className="text-[11px] leading-relaxed">
                The Volcano engine branches candidate physical algorithms (Index Scan vs Seq Scan, Nested Loop vs Hash Join) and preserves the cheapest plan in the Memo table.
              </p>
            </div>
          </div>

          <div className="p-2 bg-indigo-950/40 border border-indigo-800/60 rounded text-[11px] text-indigo-300">
            Rule transformations maintain logical equivalence while evaluating physical execution costs.
          </div>
        </div>
      </div>
    </div>
  );
}

import { useState } from 'react';
import {
  CatalystState,
  PlanNode,
  CatalystPhaseId,
  RDDStage
} from '../types/catalyst';
import {
  GitCommit,
  Layers,
  Cpu,
  FileCode,
  ArrowDown,
  Info,
  CheckCircle2,
  AlertCircle,
  Network,
  Sparkles,
  Zap,
  Boxes,
  Database
} from 'lucide-react';

interface CatalystVisualizerProps {
  state: CatalystState;
  onSelectNode?: (nodeId: string) => void;
}

type ActiveVisualizerTab = 'tree' | 'stages' | 'codegen' | 'rules';

const PHASES: Array<{ id: CatalystPhaseId; label: string; stepIdx: number }> = [
  { id: 'unresolved_logical', label: '1. Unresolved Plan', stepIdx: 0 },
  { id: 'analyzed_logical', label: '2. Analyzed Plan', stepIdx: 1 },
  { id: 'optimized_logical', label: '3. Optimized Logical', stepIdx: 2 },
  { id: 'physical_planning', label: '4. Physical Plan', stepIdx: 3 },
  { id: 'codegen_execution', label: '5. WholeStage Codegen', stepIdx: 4 },
];

export function CatalystVisualizer({ state }: CatalystVisualizerProps) {
  const [activeTab, setActiveTab] = useState<ActiveVisualizerTab>('tree');
  const [selectedNode, setSelectedNode] = useState<PlanNode | null>(null);

  const currentPhaseIdx = PHASES.findIndex((p) => p.id === state.phase);

  return (
    <div id="catalyst-visualizer" className="bg-slate-900/90 border border-slate-800 rounded-lg overflow-hidden flex flex-col h-[520px]">
      {/* Top Banner: Catalyst Phase Stepper */}
      <div className="bg-slate-950 px-3 py-2 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 text-xs font-mono">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          <span className="font-semibold text-slate-200">Catalyst Pipeline:</span>
        </div>

        {/* 5 Phase Pills */}
        <div className="flex items-center gap-1 text-[11px] font-mono overflow-x-auto py-0.5">
          {PHASES.map((p, idx) => {
            const isCompleted = idx < currentPhaseIdx;
            const isCurrent = idx === currentPhaseIdx;

            return (
              <div
                key={p.id}
                className={`flex items-center gap-1 px-2 py-0.5 rounded border transition-all ${
                  isCurrent
                    ? 'bg-cyan-950 border-cyan-500 text-cyan-300 font-bold shadow-sm shadow-cyan-900/30'
                    : isCompleted
                    ? 'bg-slate-800/80 border-slate-700 text-slate-300'
                    : 'bg-slate-900/40 border-slate-800 text-slate-500'
                }`}
              >
                {isCompleted ? (
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                ) : isCurrent ? (
                  <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                ) : (
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-600" />
                )}
                <span>{p.label}</span>
              </div>
            );
          })}
        </div>

        {/* View Mode Tabs */}
        <div className="flex items-center gap-1 bg-slate-900 p-0.5 rounded border border-slate-800 text-xs">
          <button
            onClick={() => setActiveTab('tree')}
            className={`px-2 py-1 rounded flex items-center gap-1 transition-colors ${
              activeTab === 'tree' ? 'bg-slate-800 text-cyan-300 font-medium' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Boxes className="w-3.5 h-3.5" />
            <span>Plan Tree</span>
          </button>
          <button
            onClick={() => setActiveTab('stages')}
            className={`px-2 py-1 rounded flex items-center gap-1 transition-colors ${
              activeTab === 'stages' ? 'bg-slate-800 text-cyan-300 font-medium' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Network className="w-3.5 h-3.5" />
            <span>Stage DAG</span>
          </button>
          <button
            onClick={() => setActiveTab('codegen')}
            className={`px-2 py-1 rounded flex items-center gap-1 transition-colors ${
              activeTab === 'codegen' ? 'bg-slate-800 text-cyan-300 font-medium' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>Java Codegen</span>
          </button>
          <button
            onClick={() => setActiveTab('rules')}
            className={`px-2 py-1 rounded flex items-center gap-1 transition-colors ${
              activeTab === 'rules' ? 'bg-slate-800 text-cyan-300 font-medium' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Rules ({state.ruleApplications?.length || 0})</span>
          </button>
        </div>
      </div>

      {/* Main Canvas Area */}
      <div className="flex-1 flex overflow-hidden">
        {/* Main interactive visual content */}
        <div className="flex-1 overflow-auto p-4 flex justify-center items-start">
          {activeTab === 'tree' && (
            <div className="w-full max-w-2xl py-2 flex flex-col items-center">
              <TreeNodeItem
                node={state.rootNode}
                selectedNodeId={selectedNode?.id}
                onSelectNode={(n) => setSelectedNode(n)}
              />
            </div>
          )}

          {activeTab === 'stages' && (
            <div className="w-full max-w-3xl space-y-4 py-2">
              <div className="text-xs text-slate-400 font-mono flex items-center justify-between pb-2 border-b border-slate-800">
                <span>Distributed RDD Execution Stages (DAG Scheduler)</span>
                <span>Partitions: {state.stages.reduce((acc, s) => acc + s.partitions, 0)} total</span>
              </div>

              {state.stages.length === 0 ? (
                <div className="text-center py-12 text-slate-500 text-xs">
                  Stage boundary decomposition is generated during Physical Planning and Code Generation (Phases 4 & 5).
                </div>
              ) : (
                <div className="space-y-3">
                  {state.stages.map((stage) => (
                    <StageCard key={stage.stageId} stage={stage} />
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'codegen' && (
            <div className="w-full h-full flex flex-col">
              <div className="bg-slate-950 p-2 border-b border-slate-800 text-xs font-mono text-cyan-300 flex items-center justify-between">
                <span>Janino In-Memory Java Bytecode Synthesizer</span>
                <span className="text-[11px] text-slate-400">Project Tungsten (WholeStageCodegenExec)</span>
              </div>
              <pre className="flex-1 overflow-auto p-3 font-mono text-xs text-slate-300 bg-slate-950/80 leading-relaxed select-text">
                <code>{state.generatedCode}</code>
              </pre>
            </div>
          )}

          {activeTab === 'rules' && (
            <div className="w-full max-w-2xl space-y-3 py-2">
              <div className="text-xs text-slate-400 font-mono pb-2 border-b border-slate-800">
                Catalyst RuleExecutor History (Pattern Matching Transforms)
              </div>
              {state.ruleApplications?.length === 0 ? (
                <div className="text-center py-12 text-slate-500 text-xs">
                  Rule transformations begin during Phase 2 (Analysis) and Phase 3 (Logical Optimization).
                </div>
              ) : (
                <div className="space-y-2">
                  {state.ruleApplications.map((rule, i) => (
                    <div key={i} className="bg-slate-950 p-2.5 rounded border border-slate-800 text-xs font-mono">
                      <div className="flex items-center justify-between text-cyan-300 font-semibold mb-1">
                        <span>{rule.ruleName}</span>
                        <span className="text-[10px] text-slate-500 font-normal">{rule.timeMs} ms</span>
                      </div>
                      <div className="text-slate-400 text-[11px] mb-1">{rule.description}</div>
                      <div className="text-[10px] text-indigo-400">Target: {rule.affectedNode}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Selected Node Details Drawer (Right side) */}
        {selectedNode && (
          <div className="w-72 bg-slate-950 border-l border-slate-800 p-3 overflow-auto flex flex-col text-xs">
            <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800">
              <span className="font-semibold text-cyan-300 font-mono">{selectedNode.name}</span>
              <button
                onClick={() => setSelectedNode(null)}
                className="text-slate-500 hover:text-slate-300 text-xs px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800"
              >
                Close
              </button>
            </div>

            <div className="space-y-2.5">
              <div>
                <span className="text-[10px] uppercase font-mono text-slate-500">Operation</span>
                <p className="text-slate-300 font-medium mt-0.5">{selectedNode.title}</p>
              </div>

              <div>
                <span className="text-[10px] uppercase font-mono text-slate-500">Details</span>
                <p className="text-slate-400 text-[11px] font-mono mt-0.5 break-words bg-slate-900/60 p-1.5 rounded border border-slate-800/80">
                  {selectedNode.details}
                </p>
              </div>

              {selectedNode.pushedFilters && selectedNode.pushedFilters.length > 0 && (
                <div>
                  <span className="text-[10px] uppercase font-mono text-emerald-400 font-semibold">
                    Pushed Down Filters
                  </span>
                  <ul className="mt-1 space-y-1">
                    {selectedNode.pushedFilters.map((f, i) => (
                      <li key={i} className="text-[11px] font-mono text-emerald-300 bg-emerald-950/40 border border-emerald-800/60 px-1.5 py-0.5 rounded">
                        {f}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {selectedNode.schema && selectedNode.schema.length > 0 && (
                <div>
                  <span className="text-[10px] uppercase font-mono text-slate-500">Resolved Schema</span>
                  <div className="mt-1 max-h-36 overflow-auto border border-slate-800 rounded bg-slate-900/40">
                    <table className="w-full text-[10px] font-mono">
                      <tbody>
                        {selectedNode.schema.map((attr, i) => (
                          <tr key={i} className="border-b border-slate-800/60 last:border-0">
                            <td className="p-1 text-slate-300">{attr.name}</td>
                            <td className="p-1 text-indigo-300 text-right">{attr.dataType}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {selectedNode.transformationBadge && (
                <div className="p-2 rounded bg-cyan-950/40 border border-cyan-800/60 text-[11px] text-cyan-200">
                  <span className="font-semibold block mb-0.5">Optimization Applied:</span>
                  {selectedNode.transformationBadge}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// Recursive Tree Node Renderer
function TreeNodeItem({
  node,
  selectedNodeId,
  onSelectNode,
}: {
  node: PlanNode;
  selectedNodeId?: string;
  onSelectNode: (node: PlanNode) => void;
}) {
  const isSelected = selectedNodeId === node.id;

  const getNodeColor = (type: string) => {
    switch (type) {
      case 'FileSourceScan':
      case 'LogicalRelation':
      case 'UnresolvedRelation':
        return 'border-blue-700 bg-blue-950/40 text-blue-200';
      case 'Filter':
        return 'border-emerald-700 bg-emerald-950/40 text-emerald-200';
      case 'Project':
        return 'border-indigo-700 bg-indigo-950/40 text-indigo-200';
      case 'Join':
      case 'BroadcastHashJoin':
      case 'SortMergeJoin':
        return 'border-purple-700 bg-purple-950/40 text-purple-200';
      case 'BroadcastExchange':
      case 'ShuffleExchange':
        return 'border-rose-700 bg-rose-950/40 text-rose-200';
      case 'WholeStageCodegen':
        return 'border-cyan-600 bg-cyan-950/40 text-cyan-200';
      default:
        return 'border-slate-700 bg-slate-900 text-slate-200';
    }
  };

  return (
    <div className="flex flex-col items-center">
      {/* Current Node Box */}
      <div
        onClick={() => onSelectNode(node)}
        className={`px-3 py-2 rounded border cursor-pointer transition-all max-w-md w-72 text-center relative ${getNodeColor(
          node.type
        )} ${
          isSelected
            ? 'ring-2 ring-cyan-400 shadow-lg shadow-cyan-950'
            : 'hover:brightness-110 shadow-sm'
        }`}
      >
        {node.transformationBadge && (
          <span className="absolute -top-2 right-2 text-[9px] font-mono px-1.5 py-0.2 rounded-full bg-cyan-600 text-white font-bold tracking-wide shadow">
            {node.transformationBadge}
          </span>
        )}

        <div className="text-xs font-bold font-mono tracking-tight flex items-center justify-center gap-1">
          {node.type === 'WholeStageCodegen' && <Zap className="w-3 h-3 text-cyan-400" />}
          {node.type.includes('Join') && <Sparkles className="w-3 h-3 text-purple-400" />}
          {node.type.includes('Scan') && <Database className="w-3 h-3 text-blue-400" />}
          <span>{node.title}</span>
        </div>

        <div className="text-[10px] text-slate-400 font-mono mt-0.5 truncate" title={node.details}>
          {node.details}
        </div>
      </div>

      {/* Children branches */}
      {node.children && node.children.length > 0 && (
        <div className="flex flex-col items-center">
          {/* Connector down */}
          <div className="w-px h-4 bg-slate-700" />

          {/* Children container */}
          <div className="flex items-start gap-4 relative">
            {node.children.length > 1 && (
              <div className="absolute top-0 left-12 right-12 h-px bg-slate-700" />
            )}
            {node.children.map((child) => (
              <div key={child.id} className="flex flex-col items-center">
                <div className="w-px h-3 bg-slate-700" />
                <TreeNodeItem
                  node={child}
                  selectedNodeId={selectedNodeId}
                  onSelectNode={onSelectNode}
                />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// Stage Card Renderer for Stage DAG
function StageCard({ stage }: { stage: RDDStage; key?: string | number }) {
  return (
    <div className="bg-slate-950 border border-slate-800 rounded p-3 text-xs font-mono">
      <div className="flex items-center justify-between pb-1.5 border-b border-slate-800 mb-2">
        <div className="flex items-center gap-2">
          <span className="font-bold text-cyan-300">{stage.name}</span>
          {stage.isShuffle ? (
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800">
              SHUFFLE REQUIRED
            </span>
          ) : (
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
              PIPELINED (NO SHUFFLE)
            </span>
          )}
        </div>
        <span className="text-slate-400 text-[11px]">{stage.partitions} Partitions</span>
      </div>

      <div className="flex flex-wrap items-center gap-1.5 mb-2">
        <span className="text-[10px] text-slate-500">Pipelined Operators:</span>
        {stage.operators.map((op, i) => (
          <span key={i} className="px-1.5 py-0.5 rounded bg-slate-900 text-slate-300 border border-slate-800 text-[10px]">
            {op}
          </span>
        ))}
      </div>

      {stage.isShuffle && (
        <div className="flex items-center gap-4 text-[11px] text-slate-400 pt-1 border-t border-slate-900">
          <span>Shuffle Read: <strong className="text-slate-200">{stage.shuffleReadMB} MB</strong></span>
          <span>Shuffle Write: <strong className="text-slate-200">{stage.shuffleWriteMB} MB</strong></span>
        </div>
      )}
    </div>
  );
}

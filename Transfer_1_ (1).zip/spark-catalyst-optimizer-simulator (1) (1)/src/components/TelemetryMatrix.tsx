import React from 'react';
import { MetricDefinition } from '../types/simulation';
import {
  Activity,
  Zap,
  TrendingDown,
  TrendingUp,
  AlertTriangle,
  Info,
  CheckCircle,
  HardDrive,
  Cpu,
  Network
} from 'lucide-react';

interface TelemetryMatrixProps {
  metrics: MetricDefinition[];
  values: Record<string, number>;
  previousValues?: Record<string, number>;
  topicId?: string;
  step: number;
}

export function TelemetryMatrix({
  metrics,
  values,
  previousValues,
  topicId,
  step,
}: TelemetryMatrixProps) {
  // Generate causal explanation based on real state metrics
  const getTelemetryAnalysis = () => {
    const shuffle = values['shuffleVolumeMB'] ?? 0;
    const latency = values['estimatedLatencyMs'] ?? 0;
    const scanned = values['scannedRows'] ?? 0;
    const codegen = values['codegenLines'] ?? 0;

    if (shuffle === 0 && latency < 400) {
      return {
        status: 'optimal',
        title: 'High-Efficiency Broadcast Execution',
        description: 'Zero network shuffle detected. Small table fits inside autoBroadcastJoinThreshold, allowing BroadcastHashJoin with in-memory hash probe and low latency.',
      };
    }

    if (shuffle > 0) {
      return {
        status: 'warning',
        title: 'Shuffle Network Saturation Detected',
        description: `Query triggered SortMergeJoin with ${values['shuffleExchanges'] || 2} ShuffleExchange stages, redistributing ${shuffle} MB across cluster network interfaces. Consider increasing broadcast threshold or filtering join inputs.`,
      };
    }

    if (scanned > 5000000) {
      return {
        status: 'warning',
        title: 'Heavy Disk Scan I/O',
        description: `${scanned.toLocaleString()} rows being scanned. Predicate pushdown may be disabled or column pruning unoptimized.`,
      };
    }

    return {
      status: 'neutral',
      title: 'Normal Pipelined Execution',
      description: 'Catalyst rules have structured the query plan. Pipelined execution stages are preparing distributed partitions.',
    };
  };

  const analysis = getTelemetryAnalysis();

  return (
    <div id="telemetry-matrix" className="bg-slate-900 border border-slate-800 rounded-lg p-3 text-slate-200">
      <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800 text-xs">
        <div className="flex items-center gap-1.5 font-semibold text-slate-300">
          <Activity className="w-3.5 h-3.5 text-cyan-400" />
          <span>Execution Telemetry Matrix</span>
        </div>
        <span className="text-[10px] text-slate-500 font-mono">STEP {step + 1} STATE</span>
      </div>

      {/* Grid of Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2.5 mb-3">
        {metrics.map((m) => {
          const val = values[m.id] ?? 0;
          const prevVal = previousValues ? previousValues[m.id] : undefined;
          const diff = prevVal !== undefined ? val - prevVal : 0;

          return (
            <div
              key={m.id}
              className={`p-2 rounded border bg-slate-950/70 ${
                m.isKeyMetric ? 'border-slate-700 shadow-sm' : 'border-slate-800/80'
              }`}
            >
              <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                <span className="truncate" title={m.label}>{m.label}</span>
                {m.unit && <span className="text-[10px] text-slate-500 font-mono">{m.unit}</span>}
              </div>

              <div className="flex items-baseline justify-between">
                <div className="text-sm sm:text-base font-bold font-mono text-cyan-300">
                  {typeof val === 'number' ? val.toLocaleString() : val}
                </div>

                {/* Delta indicator if changed */}
                {diff !== 0 && (
                  <div
                    className={`text-[10px] font-mono flex items-center ${
                      diff < 0 ? 'text-emerald-400' : 'text-amber-400'
                    }`}
                  >
                    {diff > 0 ? `+${diff}` : `${diff}`}
                  </div>
                )}
              </div>

              {m.description && (
                <div className="text-[9px] text-slate-500 truncate mt-1" title={m.description}>
                  {m.description}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Telemetry Interpretation Card (Required by #27) */}
      <div
        className={`p-2.5 rounded border text-xs flex items-start gap-2 ${
          analysis.status === 'optimal'
            ? 'bg-emerald-950/40 border-emerald-800/70 text-emerald-300'
            : analysis.status === 'warning'
            ? 'bg-amber-950/40 border-amber-800/70 text-amber-300'
            : 'bg-slate-950 border-slate-800 text-slate-300'
        }`}
      >
        {analysis.status === 'optimal' ? (
          <CheckCircle className="w-4 h-4 flex-shrink-0 text-emerald-400 mt-0.5" />
        ) : analysis.status === 'warning' ? (
          <AlertTriangle className="w-4 h-4 flex-shrink-0 text-amber-400 mt-0.5" />
        ) : (
          <Info className="w-4 h-4 flex-shrink-0 text-cyan-400 mt-0.5" />
        )}
        <div className="flex-1">
          <span className="font-semibold block text-[11px] uppercase tracking-wider mb-0.5">
            Telemetry Analysis: {analysis.title}
          </span>
          <p className="text-[11px] leading-relaxed text-slate-300 opacity-90">
            {analysis.description}
          </p>
        </div>
      </div>
    </div>
  );
}

import { useState } from 'react';
import { SimulationEvent } from '../types/simulation';
import { Clock, ListOrdered, ChevronRight, Zap, CheckCircle2 } from 'lucide-react';

interface TimelineEventLogProps {
  events: SimulationEvent[];
  currentStep: number;
  totalSteps: number;
  onSelectStep: (step: number) => void;
}

export function TimelineEventLog({
  events,
  currentStep,
  totalSteps,
  onSelectStep,
}: TimelineEventLogProps) {
  const [activeView, setActiveView] = useState<'timeline' | 'log'>('timeline');

  return (
    <div id="timeline-eventlog" className="bg-slate-900 border border-slate-800 rounded-lg p-3 text-slate-200">
      {/* Header & View Switcher */}
      <div className="flex items-center justify-between pb-2 mb-2.5 border-b border-slate-800 text-xs">
        <div className="flex items-center gap-1.5 font-semibold text-slate-300">
          <Clock className="w-3.5 h-3.5 text-cyan-400" />
          <span>Execution Timeline & Trace</span>
        </div>

        <div className="flex items-center bg-slate-950 p-0.5 rounded border border-slate-800 text-[11px]">
          <button
            onClick={() => setActiveView('timeline')}
            className={`px-2 py-0.5 rounded transition-colors ${
              activeView === 'timeline' ? 'bg-slate-800 text-cyan-300 font-medium' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Visual Track
          </button>
          <button
            onClick={() => setActiveView('log')}
            className={`px-2 py-0.5 rounded transition-colors ${
              activeView === 'log' ? 'bg-slate-800 text-cyan-300 font-medium' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Trace Log ({events.length})
          </button>
        </div>
      </div>

      {/* VIEW 1: Visual Scrubber Timeline */}
      {activeView === 'timeline' && (
        <div className="py-2">
          {/* Progress bar container */}
          <div className="relative flex items-center justify-between">
            {/* Horizontal connecting track line */}
            <div className="absolute left-3 right-3 top-1/2 -translate-y-1/2 h-1 bg-slate-800 rounded z-0" />
            <div
              className="absolute left-3 top-1/2 -translate-y-1/2 h-1 bg-cyan-600 rounded z-0 transition-all duration-300"
              style={{
                width: `${totalSteps > 1 ? (currentStep / (totalSteps - 1)) * 95 : 0}%`,
              }}
            />

            {/* Step markers */}
            {Array.from({ length: totalSteps }).map((_, idx) => {
              const isPast = idx < currentStep;
              const isCurrent = idx === currentStep;
              const evt = events[idx];

              return (
                <button
                  key={idx}
                  onClick={() => onSelectStep(idx)}
                  className={`relative z-10 flex flex-col items-center group focus:outline-none`}
                  title={`Jump to Step ${idx + 1}: ${evt?.label || 'Step'}`}
                >
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center font-mono text-[11px] font-bold border transition-all ${
                      isCurrent
                        ? 'bg-cyan-500 border-white text-slate-950 scale-110 shadow-md shadow-cyan-900 ring-2 ring-cyan-400'
                        : isPast
                        ? 'bg-slate-800 border-cyan-700 text-cyan-300 hover:bg-slate-700'
                        : 'bg-slate-950 border-slate-800 text-slate-600 hover:border-slate-700'
                    }`}
                  >
                    {idx + 1}
                  </div>

                  <span
                    className={`text-[9px] font-mono mt-1 max-w-[80px] text-center truncate ${
                      isCurrent ? 'text-cyan-300 font-bold' : 'text-slate-500 group-hover:text-slate-300'
                    }`}
                  >
                    {evt?.label ? evt.label.split(' ')[0] : `S${idx}`}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* VIEW 2: Chronological Event Log */}
      {activeView === 'log' && (
        <div className="max-h-44 overflow-auto space-y-1.5 pr-1 font-mono text-xs">
          {events.map((evt, idx) => {
            const isCurrent = evt.step === currentStep;

            return (
              <div
                key={evt.id || idx}
                onClick={() => onSelectStep(evt.step)}
                className={`p-2 rounded border cursor-pointer transition-colors flex items-center justify-between gap-2 ${
                  isCurrent
                    ? 'bg-cyan-950/60 border-cyan-600 text-cyan-200 font-semibold'
                    : 'bg-slate-950/60 border-slate-800/80 text-slate-400 hover:bg-slate-800/60'
                }`}
              >
                <div className="flex items-center gap-2 truncate">
                  <span className="text-[10px] text-slate-500">[{evt.timestamp}]</span>
                  <span className="text-[10px] px-1 py-0.2 rounded bg-slate-800 text-slate-300 border border-slate-700">
                    STEP {evt.step + 1}
                  </span>
                  <span className="text-slate-200 truncate">{evt.label}</span>
                </div>

                <div className="flex items-center gap-2 flex-shrink-0">
                  {evt.sourceLine && (
                    <span className="text-[10px] text-indigo-400">Line {evt.sourceLine}</span>
                  )}
                  {isCurrent && <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

import React from 'react';
import { MetricDefinition } from '../types/simulation';
import { X, GitCompare, ArrowRight, TrendingDown, TrendingUp, Minus, AlertCircle } from 'lucide-react';

interface ComparisonModalProps {
  isOpen: boolean;
  onClose: () => void;
  metrics: MetricDefinition[];
  benchmarkMetrics: Record<string, number>;
  customMetrics: Record<string, number>;
  benchmarkTitle?: string;
  customTitle?: string;
}

export function ComparisonModal({
  isOpen,
  onClose,
  metrics,
  benchmarkMetrics,
  customMetrics,
  benchmarkTitle = 'Default Benchmark Run',
  customTitle = 'Custom Configuration Run',
}: ComparisonModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl max-w-3xl w-full max-h-[85vh] flex flex-col overflow-hidden text-slate-200">
        {/* Modal Header */}
        <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <GitCompare className="w-4 h-4 text-indigo-400" />
            <span className="font-bold text-sm">Execution Comparative Analysis</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-slate-800 text-slate-400 hover:text-slate-200 rounded transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-auto p-4 space-y-4 text-xs">
          {/* Causal Chain Breakdown (#34) */}
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <span className="font-semibold text-cyan-300 font-mono text-[11px] block mb-2 uppercase">
              Causal Chain of Differences
            </span>
            <div className="flex flex-wrap items-center gap-2 text-slate-300">
              <span className="px-2 py-1 rounded bg-slate-900 border border-slate-700">
                User Configuration / Query Delta
              </span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-500 flex-shrink-0" />
              <span className="px-2 py-1 rounded bg-slate-900 border border-slate-700">
                Catalyst Rule Evaluation
              </span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-500 flex-shrink-0" />
              <span className="px-2 py-1 rounded bg-slate-900 border border-slate-700">
                Physical Join & Exchange Strategy
              </span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-500 flex-shrink-0" />
              <span className="px-2 py-1 rounded bg-indigo-950 text-indigo-200 border border-indigo-700 font-semibold">
                Telemetry & Runtime Latency
              </span>
            </div>
          </div>

          {/* Metrics Diff Table (#30, #31) */}
          <div className="border border-slate-800 rounded-lg overflow-hidden">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-950/80 border-b border-slate-800 text-[11px] text-slate-400 font-mono">
                  <th className="p-2.5">Metric</th>
                  <th className="p-2.5 text-right">{benchmarkTitle}</th>
                  <th className="p-2.5 text-right">{customTitle}</th>
                  <th className="p-2.5 text-right">Variance</th>
                  <th className="p-2.5 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 font-mono">
                {metrics.map((m) => {
                  const bVal = benchmarkMetrics[m.id] ?? 0;
                  const cVal = customMetrics[m.id] ?? 0;
                  const diff = cVal - bVal;
                  const pct = bVal !== 0 ? Math.round((diff / bVal) * 100) : (cVal > 0 ? 100 : 0);

                  // Lower is better for latency, shuffle, memory, scanned rows
                  const lowerIsBetter = ['estimatedLatencyMs', 'shuffleVolumeMB', 'shuffleExchanges', 'projectedMemoryMB', 'scannedRows'].includes(m.id);
                  const isImprovement = lowerIsBetter ? diff < 0 : diff > 0;
                  const isDegradation = lowerIsBetter ? diff > 0 : diff < 0;

                  return (
                    <tr key={m.id} className="hover:bg-slate-950/40">
                      <td className="p-2.5 text-slate-300 font-sans">
                        <div className="font-medium text-xs">{m.label}</div>
                        {m.unit && <div className="text-[10px] text-slate-500">{m.unit}</div>}
                      </td>
                      <td className="p-2.5 text-right text-slate-300">
                        {typeof bVal === 'number' ? bVal.toLocaleString() : bVal}
                      </td>
                      <td className="p-2.5 text-right text-cyan-300 font-semibold">
                        {typeof cVal === 'number' ? cVal.toLocaleString() : cVal}
                      </td>
                      <td className="p-2.5 text-right">
                        {diff === 0 ? (
                          <span className="text-slate-500 font-mono">0% (Equal)</span>
                        ) : (
                          <span className={`font-mono ${isImprovement ? 'text-emerald-400' : 'text-amber-400'}`}>
                            {diff > 0 ? `+${pct}%` : `${pct}%`}
                          </span>
                        )}
                      </td>
                      <td className="p-2.5 text-center">
                        {diff === 0 ? (
                          <span className="px-1.5 py-0.5 rounded text-[10px] bg-slate-800 text-slate-400">
                            Unchanged
                          </span>
                        ) : isImprovement ? (
                          <span className="px-1.5 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 flex items-center justify-center gap-1">
                            <TrendingDown className="w-3 h-3" /> Improved
                          </span>
                        ) : (
                          <span className="px-1.5 py-0.5 rounded text-[10px] bg-amber-950 text-amber-300 border border-amber-800 flex items-center justify-center gap-1">
                            <TrendingUp className="w-3 h-3" /> Regression
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Qualitative Takeaway */}
          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 text-slate-300 text-xs leading-relaxed">
            <strong className="text-cyan-300 font-mono block mb-1">Optimizer Observation:</strong>
            Comparing the execution profiles reveals how parameter and query alterations shift the underlying execution plan. When data sizes or broadcast thresholds are altered, Catalyst either avoids network shuffles completely (BroadcastHashJoin) or inserts ShuffleExchange partitions (SortMergeJoin).
          </div>
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-950 px-4 py-2.5 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs transition-colors"
          >
            Close Comparison
          </button>
        </div>
      </div>
    </div>
  );
}

import { useState, useEffect } from 'react';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  RotateCcw,
  Sparkles,
  Zap,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Settings2
} from 'lucide-react';
import { SimulationStatus, ExecutionMode } from '../types/simulation';

interface ControlDeckProps {
  status: SimulationStatus;
  mode: ExecutionMode;
  currentStep: number;
  totalSteps: number;
  playbackSpeed: number;
  activeEventLabel?: string;
  onPlay: () => void;
  onPause: () => void;
  onPrevStep: () => void;
  onNextStep: () => void;
  onReset: () => void;
  onResetToDefault: () => void;
  onSpeedChange: (speed: number) => void;
  onToggleParams?: () => void;
  isParamsOpen?: boolean;
}

export function ControlDeck({
  status,
  mode,
  currentStep,
  totalSteps,
  playbackSpeed,
  activeEventLabel,
  onPlay,
  onPause,
  onPrevStep,
  onNextStep,
  onReset,
  onResetToDefault,
  onSpeedChange,
  onToggleParams,
  isParamsOpen,
}: ControlDeckProps) {
  const isRunning = status === 'running';
  const isFirstStep = currentStep === 0;
  const isLastStep = currentStep >= totalSteps - 1;

  const speeds = [0.5, 1, 2, 4];

  return (
    <div id="control-deck" className="bg-slate-900 border-b border-slate-800 px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 text-sm select-none">
      {/* Playback step controls */}
      <div className="flex items-center gap-1.5">
        <button
          id="btn-prev-step"
          onClick={onPrevStep}
          disabled={isFirstStep || isRunning}
          title="Previous Step (Left Arrow)"
          className={`px-2.5 py-1.5 rounded flex items-center gap-1 font-medium transition-colors ${
            isFirstStep || isRunning
              ? 'text-slate-600 bg-slate-800/40 cursor-not-allowed'
              : 'text-slate-200 bg-slate-800 hover:bg-slate-700 active:scale-95'
          }`}
        >
          <SkipBack className="w-4 h-4" />
          <span className="hidden sm:inline">Prev</span>
        </button>

        <button
          id="btn-play-pause"
          onClick={isRunning ? onPause : onPlay}
          title="Play/Pause (Space)"
          className={`px-3 py-1.5 rounded flex items-center gap-1.5 font-semibold text-white transition-all shadow-sm ${
            isRunning
              ? 'bg-amber-600 hover:bg-amber-500'
              : 'bg-emerald-600 hover:bg-emerald-500'
          }`}
        >
          {isRunning ? (
            <>
              <Pause className="w-4 h-4 fill-current" />
              <span>Pause</span>
            </>
          ) : (
            <>
              <Play className="w-4 h-4 fill-current" />
              <span>{isLastStep ? 'Replay' : 'Play'}</span>
            </>
          )}
        </button>

        <button
          id="btn-next-step"
          onClick={onNextStep}
          disabled={isLastStep || isRunning}
          title="Next Step (Right Arrow)"
          className={`px-2.5 py-1.5 rounded flex items-center gap-1 font-medium transition-colors ${
            isLastStep || isRunning
              ? 'text-slate-600 bg-slate-800/40 cursor-not-allowed'
              : 'text-slate-200 bg-slate-800 hover:bg-slate-700 active:scale-95'
          }`}
        >
          <span className="hidden sm:inline">Next</span>
          <SkipForward className="w-4 h-4" />
        </button>

        <div className="h-4 w-px bg-slate-800 mx-1" />

        {/* Reset button */}
        <button
          id="btn-reset-step"
          onClick={onReset}
          title="Reset to Step 0 (R)"
          className="px-2 py-1.5 rounded text-slate-300 bg-slate-800/60 hover:bg-slate-800 hover:text-white transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
        </button>

        {mode === 'CUSTOM' && (
          <button
            id="btn-reset-default"
            onClick={onResetToDefault}
            title="Reset to Canonical Benchmark"
            className="px-2.5 py-1 text-xs rounded border border-slate-700 text-amber-300 hover:bg-amber-950/40 transition-colors flex items-center gap-1"
          >
            <Sparkles className="w-3 h-3 text-amber-400" />
            <span>Reset to Default</span>
          </button>
        )}
      </div>

      {/* Current event banner */}
      <div className="hidden lg:flex items-center gap-2 bg-slate-950/70 border border-slate-800/80 px-3 py-1 rounded max-w-md truncate">
        <span className="text-xs uppercase font-mono text-cyan-400 flex items-center gap-1 flex-shrink-0">
          <Zap className="w-3 h-3" /> Event:
        </span>
        <span className="text-xs text-slate-300 truncate" title={activeEventLabel}>
          {activeEventLabel || 'Simulation Initialized'}
        </span>
      </div>

      {/* Playback speed & parameter toggles */}
      <div className="flex items-center gap-2">
        <div className="flex items-center bg-slate-800/80 rounded p-0.5 border border-slate-700/60 text-xs">
          <Clock className="w-3 h-3 text-slate-400 ml-1.5 mr-1" />
          {speeds.map((s) => (
            <button
              key={s}
              id={`btn-speed-${s}x`}
              onClick={() => onSpeedChange(s)}
              className={`px-2 py-0.5 rounded font-mono transition-colors ${
                playbackSpeed === s
                  ? 'bg-cyan-600 text-white font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {s}×
            </button>
          ))}
        </div>

        {onToggleParams && (
          <button
            id="btn-toggle-params"
            onClick={onToggleParams}
            className={`px-2.5 py-1 rounded border text-xs font-medium flex items-center gap-1.5 transition-colors ${
              isParamsOpen
                ? 'bg-cyan-950 border-cyan-700 text-cyan-300'
                : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <Settings2 className="w-3.5 h-3.5 text-cyan-400" />
            <span>Parameters</span>
          </button>
        )}
      </div>
    </div>
  );
}

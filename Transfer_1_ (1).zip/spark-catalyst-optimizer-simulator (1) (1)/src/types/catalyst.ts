/**
 * Spark Catalyst Optimizer domain types.
 * Models the AST, Logical Plans, Optimization Rules, Physical Plans, and Codegen Stages.
 */

export type CatalystPhaseId = 
  | 'unresolved_logical'
  | 'analyzed_logical'
  | 'optimized_logical'
  | 'physical_planning'
  | 'codegen_execution';

export interface CatalystPhaseMeta {
  id: CatalystPhaseId;
  name: string;
  shortName: string;
  stageNumber: number;
  description: string;
}

export type PlanNodeType =
  | 'UnresolvedRelation'
  | 'LogicalRelation'
  | 'Filter'
  | 'Project'
  | 'Join'
  | 'Aggregate'
  | 'Sort'
  | 'BroadcastExchange'
  | 'ShuffleExchange'
  | 'BroadcastHashJoin'
  | 'SortMergeJoin'
  | 'ShuffledHashJoin'
  | 'HashAggregate'
  | 'FileSourceScan'
  | 'WholeStageCodegen';

export interface PlanAttribute {
  name: string;
  dataType: string;
  nullable?: boolean;
}

export interface PlanNode {
  id: string;
  type: PlanNodeType;
  name: string;
  title: string;
  details: string;
  schema?: PlanAttribute[];
  pushedFilters?: string[];
  outputColumns?: string[];
  joinType?: 'INNER' | 'LEFT' | 'RIGHT' | 'FULL';
  joinCondition?: string;
  sortKeys?: string[];
  partitionKeys?: string[];
  costEstimate?: {
    rows: number;
    sizeBytes: number;
    cpuCost: number;
  };
  isWholeStageCodegen?: boolean;
  codegenStageId?: number;
  isTransformed?: boolean;
  transformationBadge?: string;
  children: PlanNode[];
}

export interface CatalystRule {
  id: string;
  name: string;
  phase: CatalystPhaseId;
  description: string;
  scalaClass: string;
  category: 'Analysis' | 'LogicalOptimization' | 'PhysicalPlanning' | 'CodeGeneration';
}

export interface RDDStage {
  stageId: number;
  name: string;
  operators: string[];
  partitions: number;
  parentStageIds: number[];
  isShuffle: boolean;
  shuffleReadMB: number;
  shuffleWriteMB: number;
  status: 'pending' | 'active' | 'completed';
}

export interface CatalystState {
  phase: CatalystPhaseId;
  phaseIndex: number;
  totalPhases: number;
  activeRule?: {
    name: string;
    description: string;
    scalaRule: string;
    beforeSummary: string;
    afterSummary: string;
  };
  rootNode: PlanNode;
  previousRootNode?: PlanNode;
  selectedNodeId?: string;
  stages: RDDStage[];
  generatedCode: string;
  ruleApplications: Array<{
    ruleName: string;
    timeMs: number;
    affectedNode: string;
    description: string;
  }>;
  tableMetadata: Record<string, {
    tableName: string;
    rowCount: number;
    sizeBytes: number;
    schema: PlanAttribute[];
    fileFormat: string;
    location: string;
  }>;
}

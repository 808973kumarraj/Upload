/**
 * Core topic-agnostic simulation types and interfaces.
 * Defines the contract for any technical simulation topic plugged into the workstation.
 */

export type SimulationStatus = 'idle' | 'running' | 'paused' | 'completed' | 'error';
export type ExecutionMode = 'DEFAULT' | 'CUSTOM';
export type ExplanationDepth = 'beginner' | 'technical' | 'internals';

export interface ParameterOption {
  label: string;
  value: string | number | boolean;
  description?: string;
}

export interface ParameterDefinition {
  id: string;
  label: string;
  type: 'number' | 'boolean' | 'select' | 'range' | 'text';
  defaultValue: any;
  min?: number;
  max?: number;
  step?: number;
  unit?: string;
  options?: ParameterOption[];
  description?: string;
  category?: string;
}

export interface MetricDefinition {
  id: string;
  label: string;
  unit?: string;
  format?: 'number' | 'bytes' | 'duration' | 'percentage' | 'count';
  description?: string;
  isKeyMetric?: boolean;
}

export interface SimulationEvent {
  id: string;
  step: number;
  timestamp: string;
  type: string;
  label: string;
  description: string;
  sourceLine?: number;
  phase?: string;
  impact?: 'neutral' | 'optimization' | 'cost_reduction' | 'transformation' | 'warning';
  metadata?: Record<string, any>;
}

export interface StepExplanation {
  step: number;
  phase: string;
  title: string;
  whatHappened: string;
  whyItHappened: string;
  underlyingMechanism: string;
  consequences: string;
  technicalDetails?: string;
  depths?: {
    beginner: string;
    technical: string;
    internals: string;
  };
}

export interface ValidationIssue {
  line?: number;
  column?: number;
  message: string;
  severity: 'error' | 'warning';
}

export interface ValidationResult {
  isValid: boolean;
  issues: ValidationIssue[];
}

export interface SimulationSnapshot<TState = any> {
  step: number;
  mode: ExecutionMode;
  state: TState;
  metrics: Record<string, number>;
  activeLine?: number;
  event?: SimulationEvent;
  explanation?: StepExplanation;
}

export interface ScenarioPreset {
  id: string;
  name: string;
  description: string;
  code: string;
  parameters?: Record<string, any>;
}

export interface TopicDocs {
  overview: string;
  inputs: string;
  executionModel: string;
  importantConcepts: string[];
  performanceImplications: string;
  simulationNotes: string;
}

export interface SimulationTopic<TState = any, TInput = string> {
  id: string;
  name: string;
  shortName: string;
  category: string;
  description: string;
  inputLanguage: string;
  defaultCode: string;
  presets: ScenarioPreset[];
  parameters: ParameterDefinition[];
  metrics: MetricDefinition[];
  docs: TopicDocs;

  // Engine hooks
  parse: (input: TInput) => { ast: any; error?: string };
  validate: (input: TInput, params: Record<string, any>) => ValidationResult;
  buildExecutionPlan: (input: TInput, params: Record<string, any>) => {
    steps: SimulationSnapshot<TState>[];
    totalSteps: number;
  };
}

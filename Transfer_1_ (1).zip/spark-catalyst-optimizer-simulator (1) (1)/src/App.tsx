/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import { SIMULATION_TOPICS, getTopicById } from './topics/registry';
import {
  SimulationTopic,
  ExecutionMode,
  SimulationStatus,
  ExplanationDepth,
  SimulationSnapshot,
  ValidationResult,
  ScenarioPreset,
} from './types/simulation';
import { Header, WorkbenchView } from './components/Header';
import { ControlDeck } from './components/ControlDeck';
import { Workbench } from './components/Workbench';
import { ParameterPanel } from './components/ParameterPanel';
import { VisualizerRouter } from './components/VisualizerRouter';
import { TelemetryMatrix } from './components/TelemetryMatrix';
import { TimelineEventLog } from './components/TimelineEventLog';
import { DeepInspector } from './components/DeepInspector';
import { ComparisonModal } from './components/ComparisonModal';
import { TopicDocsModal } from './components/TopicDocsModal';

export default function App() {
  // Topic state
  const [activeTopic, setActiveTopic] = useState<SimulationTopic>(SIMULATION_TOPICS[0]);
  const [activePreset, setActivePreset] = useState<ScenarioPreset>(activeTopic.presets[0]);

  // Code state
  const [benchmarkCode, setBenchmarkCode] = useState<string>(activeTopic.defaultCode);
  const [editCode, setEditCode] = useState<string>(activeTopic.defaultCode);
  const [validationResult, setValidationResult] = useState<ValidationResult>({ isValid: true, issues: [] });

  // Parameters state
  const [paramValues, setParamValues] = useState<Record<string, any>>(() => {
    const initial: Record<string, any> = {};
    activeTopic.parameters.forEach((p) => {
      initial[p.id] = p.defaultValue;
    });
    return initial;
  });

  // UI state
  const [activeView, setActiveView] = useState<WorkbenchView>('split');
  const [explanationDepth, setExplanationDepth] = useState<ExplanationDepth>('technical');
  const [isParamsOpen, setIsParamsOpen] = useState(false);
  const [isDocsOpen, setIsDocsOpen] = useState(false);
  const [isComparisonOpen, setIsComparisonOpen] = useState(false);

  // Simulation execution state
  const [mode, setMode] = useState<ExecutionMode>('DEFAULT');
  const [status, setStatus] = useState<SimulationStatus>('idle');
  const [currentStep, setCurrentStep] = useState<number>(0);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);

  // Simulation plan snapshots
  const [snapshots, setSnapshots] = useState<SimulationSnapshot[]>(() => {
    const { steps } = activeTopic.buildExecutionPlan(activeTopic.defaultCode, {});
    return steps;
  });

  // Baseline benchmark snapshots for comparison
  const [benchmarkSnapshots, setBenchmarkSnapshots] = useState<SimulationSnapshot[]>(snapshots);

  // Initialize or change topic
  const handleSelectTopic = (topicId: string) => {
    const newTopic = getTopicById(topicId);
    setActiveTopic(newTopic);
    const firstPreset = newTopic.presets[0];
    setActivePreset(firstPreset);
    setBenchmarkCode(firstPreset ? firstPreset.code : newTopic.defaultCode);
    setEditCode(firstPreset ? firstPreset.code : newTopic.defaultCode);

    const initialParams: Record<string, any> = {};
    newTopic.parameters.forEach((p) => {
      initialParams[p.id] = firstPreset?.parameters?.[p.id] ?? p.defaultValue;
    });
    setParamValues(initialParams);

    const { steps } = newTopic.buildExecutionPlan(firstPreset ? firstPreset.code : newTopic.defaultCode, initialParams);
    setSnapshots(steps);
    setBenchmarkSnapshots(steps);
    setCurrentStep(0);
    setMode('DEFAULT');
    setStatus('idle');
  };

  // Change preset scenario
  const handleSelectPreset = (preset: ScenarioPreset) => {
    setActivePreset(preset);
    setBenchmarkCode(preset.code);
    setEditCode(preset.code);

    const newParams = { ...paramValues, ...(preset.parameters || {}) };
    setParamValues(newParams);

    const { steps } = activeTopic.buildExecutionPlan(preset.code, newParams);
    setSnapshots(steps);
    setBenchmarkSnapshots(steps);
    setCurrentStep(0);
    setMode('DEFAULT');
    setStatus('idle');
  };

  // Parameter changes
  const handleParamChange = (id: string, value: any) => {
    const updated = { ...paramValues, [id]: value };
    setParamValues(updated);

    // Rebuild plan with updated parameters
    const currentCode = mode === 'CUSTOM' ? editCode : benchmarkCode;
    const { steps } = activeTopic.buildExecutionPlan(currentCode, updated);
    setSnapshots(steps);
    if (mode === 'DEFAULT') {
      setBenchmarkSnapshots(steps);
    }
  };

  const handleResetParams = () => {
    const initialParams: Record<string, any> = {};
    activeTopic.parameters.forEach((p) => {
      initialParams[p.id] = activePreset?.parameters?.[p.id] ?? p.defaultValue;
    });
    setParamValues(initialParams);

    const currentCode = mode === 'CUSTOM' ? editCode : benchmarkCode;
    const { steps } = activeTopic.buildExecutionPlan(currentCode, initialParams);
    setSnapshots(steps);
  };

  // Execute custom input manually (#9)
  const handleExecuteCustom = () => {
    const valResult = activeTopic.validate(editCode, paramValues);
    setValidationResult(valResult);

    if (!valResult.isValid) {
      setStatus('error');
      return;
    }

    const { steps } = activeTopic.buildExecutionPlan(editCode, paramValues);
    setSnapshots(steps);
    setMode('CUSTOM');
    setCurrentStep(0);
    setStatus('paused');
  };

  // Copy benchmark to edit space (#6)
  const handleCopyToEditSpace = () => {
    setEditCode(benchmarkCode);
  };

  // Reset to default canonical benchmark (#13)
  const handleResetToDefault = () => {
    const code = activePreset ? activePreset.code : activeTopic.defaultCode;
    setEditCode(code);
    setBenchmarkCode(code);
    setValidationResult({ isValid: true, issues: [] });

    const initialParams: Record<string, any> = {};
    activeTopic.parameters.forEach((p) => {
      initialParams[p.id] = activePreset?.parameters?.[p.id] ?? p.defaultValue;
    });
    setParamValues(initialParams);

    const { steps } = activeTopic.buildExecutionPlan(code, initialParams);
    setSnapshots(steps);
    setBenchmarkSnapshots(steps);
    setMode('DEFAULT');
    setCurrentStep(0);
    setStatus('idle');
  };

  // Step navigation (#11, #12)
  const handleNextStep = useCallback(() => {
    setCurrentStep((prev) => {
      if (prev < snapshots.length - 1) {
        return prev + 1;
      }
      setStatus('completed');
      return prev;
    });
  }, [snapshots.length]);

  const handlePrevStep = useCallback(() => {
    setCurrentStep((prev) => {
      if (prev > 0) {
        if (status === 'completed') setStatus('paused');
        return prev - 1;
      }
      return 0;
    });
  }, [status]);

  const handleReset = () => {
    setCurrentStep(0);
    setStatus('paused');
  };

  const handlePlay = () => {
    if (currentStep >= snapshots.length - 1) {
      setCurrentStep(0);
    }
    setStatus('running');
  };

  const handlePause = () => {
    setStatus('paused');
  };

  // Playback timer loop
  useEffect(() => {
    let timer: any;
    if (status === 'running') {
      const intervalMs = Math.round(1800 / playbackSpeed);
      timer = setInterval(() => {
        setCurrentStep((prev) => {
          if (prev < snapshots.length - 1) {
            return prev + 1;
          } else {
            setStatus('completed');
            return prev;
          }
        });
      }, intervalMs);
    }
    return () => clearInterval(timer);
  }, [status, playbackSpeed, snapshots.length]);

  // Global Keyboard Controls (#56)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept if user is typing in the textarea
      if (
        document.activeElement?.tagName === 'TEXTAREA' ||
        document.activeElement?.tagName === 'INPUT'
      ) {
        return;
      }

      if (e.code === 'Space') {
        e.preventDefault();
        if (status === 'running') {
          handlePause();
        } else {
          handlePlay();
        }
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        handleNextStep();
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        handlePrevStep();
      } else if (e.key.toLowerCase() === 'r') {
        e.preventDefault();
        handleReset();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [status, handleNextStep, handlePrevStep]);

  // Current active snapshot
  const activeSnapshot = snapshots[currentStep] || snapshots[0];
  const previousSnapshot = currentStep > 0 ? snapshots[currentStep - 1] : undefined;
  const events = snapshots.map((s) => s.event).filter(Boolean) as any[];

  const lastBenchmarkSnapshot = benchmarkSnapshots[benchmarkSnapshots.length - 1] || benchmarkSnapshots[0];
  const lastCustomSnapshot = snapshots[snapshots.length - 1] || snapshots[0];

  return (
    <div id="workstation-root" className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-900 selection:text-white">
      {/* 1. Header / Topic Selector / Execution Status Bar (#49, #57) */}
      <Header
        topics={SIMULATION_TOPICS}
        activeTopic={activeTopic}
        onSelectTopic={handleSelectTopic}
        activePreset={activePreset}
        onSelectPreset={handleSelectPreset}
        mode={mode}
        status={status}
        currentStep={currentStep}
        totalSteps={snapshots.length}
        activeView={activeView}
        onChangeView={setActiveView}
        onOpenDocs={() => setIsDocsOpen(true)}
        onOpenComparison={() => setIsComparisonOpen(true)}
      />

      {/* 2. Simulation Control Deck (#15, #16) */}
      <ControlDeck
        status={status}
        mode={mode}
        currentStep={currentStep}
        totalSteps={snapshots.length}
        playbackSpeed={playbackSpeed}
        activeEventLabel={activeSnapshot?.event?.label}
        onPlay={handlePlay}
        onPause={handlePause}
        onPrevStep={handlePrevStep}
        onNextStep={handleNextStep}
        onReset={handleReset}
        onResetToDefault={handleResetToDefault}
        onSpeedChange={setPlaybackSpeed}
        onToggleParams={() => setIsParamsOpen(!isParamsOpen)}
        isParamsOpen={isParamsOpen}
      />

      {/* 3. Code / Input Workbench: Default Benchmark vs Edit Space (#4, #5, #7) */}
      <Workbench
        benchmarkCode={benchmarkCode}
        editCode={editCode}
        onChangeEditCode={setEditCode}
        activeLine={activeSnapshot?.activeLine}
        view={activeView}
        validationResult={validationResult}
        onExecuteCustom={handleExecuteCustom}
        onCopyToEditSpace={handleCopyToEditSpace}
        isExecuting={status === 'running'}
      />

      {/* Main Workspace Layout: Visualizer, Parameters, Telemetry, Inspector (#49) */}
      <main className="flex-1 p-3 sm:p-4 max-w-[1720px] mx-auto w-full space-y-4">
        {/* Row A: Main Interactive Visualizer & Dynamic Parameter Panel */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Main Visualizer Router */}
          <div className={isParamsOpen ? 'lg:col-span-8 xl:col-span-9' : 'lg:col-span-12'}>
            <VisualizerRouter
              topic={activeTopic}
              state={activeSnapshot.state}
            />
          </div>

          {/* Collapsible / Dynamic Parameter Panel (#17, #18) */}
          {isParamsOpen && (
            <div className="lg:col-span-4 xl:col-span-3">
              <ParameterPanel
                parameters={activeTopic.parameters}
                values={paramValues}
                onChange={handleParamChange}
                onResetParams={handleResetParams}
              />
            </div>
          )}
        </div>

        {/* Row B: Telemetry Matrix (#25, #26, #27) */}
        <TelemetryMatrix
          metrics={activeTopic.metrics}
          values={activeSnapshot.metrics || {}}
          previousValues={previousSnapshot?.metrics}
          topicId={activeTopic.id}
          step={currentStep}
        />

        {/* Row C: Timeline & Chronological Event Log (#23, #24) */}
        <TimelineEventLog
          events={events}
          currentStep={currentStep}
          totalSteps={snapshots.length}
          onSelectStep={(s) => {
            setCurrentStep(s);
            if (status === 'completed') setStatus('paused');
          }}
        />

        {/* Row D: Deep Technical Inspector (#28, #29) */}
        <DeepInspector
          explanation={activeSnapshot.explanation}
          depth={explanationDepth}
          onChangeDepth={setExplanationDepth}
        />
      </main>

      {/* Before / After Comparison Modal (#30, #31, #72) */}
      <ComparisonModal
        isOpen={isComparisonOpen}
        onClose={() => setIsComparisonOpen(false)}
        metrics={activeTopic.metrics}
        benchmarkMetrics={lastBenchmarkSnapshot?.metrics || {}}
        customMetrics={lastCustomSnapshot?.metrics || {}}
        benchmarkTitle="Default Benchmark (Canonical)"
        customTitle={mode === 'CUSTOM' ? 'Custom Run' : 'Current Active Plan'}
      />

      {/* Architecture & Documentation Guide Modal (#61, #62) */}
      <TopicDocsModal
        isOpen={isDocsOpen}
        onClose={() => setIsDocsOpen(false)}
        topicName={activeTopic.name}
        docs={activeTopic.docs}
      />
    </div>
  );
}
